-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ferreteria
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `Cod_Empleado` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Direccion` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT NULL,
  `FechaIngreso` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Cedula` varchar(14) DEFAULT NULL,
  `Contraseña` varchar(255) DEFAULT '1234',
  PRIMARY KEY (`Cod_Empleado`),
  CONSTRAINT `CHK_Cedula_Formato` CHECK (regexp_like(`Cedula`,_utf8mb4'^[0-9]{13}[A-Z]$'))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,'Luis','Torres','Barrio San Luis','Activo','2025-05-05 21:37:54','0012304561234A','$2b$10$nrKUIwz5qNlyBGI7eI3ceeb.mWWIwyxNAaJnOrbJBYN/MBdEzDItq'),(2,'Sofia','Alvarado','Colonial Luis','Activo','2025-05-18 03:19:26','0012610001030Y','$2b$10$bNDzrRXNy/oelBCtKlkz5OcmJ381lglaunwoHYZsWpAE2ltsQnGWG'),(3,'Jorge','Mendez','Barrio San Luis','Activo','2025-05-18 03:20:12','0013001972015Q','$2b$10$Zi5pN4H7xth4RLeCA2Uxs.lDiLYjsY8gK42yVjKPwuNO.6tLqP5kC'),(4,'Maria','Juarez','Barrio San Sebastian','Activo','2025-05-19 05:26:38','1112512983033M','$2b$10$z6vxc6Aqp6edbw4o.VFia.HhE2ae0hMAt/ABTDtw/La1sGh2ICzAy'),(5,'Paulo','Rivera','Barrio San Luis','Activo','2025-05-19 05:27:57','1810906954411J','$2b$10$k69KcY5u1WcPQ5Hxwzf0be/CFEOKphckPvbxg0vpi.fIC4W8vg/Fm');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `Cod_Producto` int NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Marca` varchar(50) DEFAULT NULL,
  `FechaVencimiento` date DEFAULT NULL,
  `Sector` varchar(50) DEFAULT NULL,
  `Estado` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'Activo',
  PRIMARY KEY (`Cod_Producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Llave Inglesa 10\"','Truper',NULL,'Herramientas manuales','Activo'),(2,'Juego de destornilladores','	Stanley',NULL,'Herramientas manuales','Activo'),(3,'Serrucho manual','	Bellota',NULL,'Herramientas manuales','Activo'),(4,'	Martillo carpintero','	Pretul',NULL,'Herramientas manuales','Activo'),(5,'	Cinta métrica 5m','Truper',NULL,'Herramientas manuales','Activo'),(6,'	Taladro percutor','	Bosch',NULL,'Herramientas eléctricas','Activo'),(7,'	Sierra circular 7\"','	Makita',NULL,'Herramientas eléctricas','Activo'),(8,'Pulidora angular','	Dewalt',NULL,'Herramientas eléctricas','Activo'),(9,'	Caladora eléctrica','	Black+Decker',NULL,'Herramientas eléctricas','Activo'),(10,'	Soldador inverter','	Koblenz',NULL,'Herramientas eléctricas','Activo'),(11,'	Bolsa de cemento 42.5kg','Holcim','2025-05-17','Materiales de construcción','Activo'),(12,'Varilla corrugada 3/8\"','	Aceros',NULL,'Materiales de construcción','Activo'),(13,'Arena fina m3','NicaMateriales',NULL,'Materiales de construcción','Activo'),(14,'Bloque de concreto','	Durabloque',NULL,'Materiales de construcción','Activo'),(15,'Mortero seco','Cemex','2025-05-23','Materiales de construcción','Activo'),(16,'Pintura látex blanco 1gal','Sur','2025-06-28','Pinturas o accesorios','Activo'),(17,'Rodillo para pintar','Truper',NULL,'Pinturas o accesorios','Activo'),(18,'Brocha 2\"','Venusa',NULL,'Pinturas o accesorios','Activo'),(19,'	Pintura esmalte negro 1gal','Lanco','2027-06-18','Pinturas o accesorios','Activo'),(20,'Diluyente 1lt','Solven','2025-12-25','Pinturas o accesorios','Activo'),(21,'Tubería PVC 1/2\" x 3m','	Nicaplast',NULL,'Tuberías y plomería','Activo'),(22,'Llave de paso 1/2\"','PAVCO',NULL,'Tuberías y plomería','Activo'),(23,'Conector PVC 3/4\"','	Nicaplast',NULL,'Tuberías y plomería','Activo'),(24,'	Cinta teflón','Teflonex',NULL,'Tuberías y plomería','Activo'),(25,'Pegamento para PVC 125ml','Pegafix','2025-10-17','Tuberías y plomería','Activo'),(26,'Bombillo LED 9W','Philips',NULL,'Electricidad e iluminación','Activo'),(27,'Tomacorriente doble','Bticino',NULL,'Electricidad e iluminación','Activo'),(28,'Cable THHN 12 AWG x metro','Condumex',NULL,'Electricidad e iluminación','Activo'),(29,'Interruptor sencillo','	Bticino',NULL,'Electricidad e iluminación','Activo'),(30,'Lámpara LED 60cm','Osram',NULL,'Electricidad e iluminación','Activo'),(31,'Casco de seguridad','3M',NULL,'Seguridad industrial','Activo'),(32,'Chaleco reflectivo','MSA',NULL,'Seguridad industrial','Activo'),(33,'Lentes de protección','Venprotex',NULL,'Seguridad industrial','Activo'),(34,'	Mascarilla N95','3M','2025-07-18','Seguridad industrial','Activo'),(35,'Guantes de cuero','Dexter',NULL,'Seguridad industrial','Activo'),(36,'Silicona transparente 280ml','	Sista','2026-06-09','Productos de ferretería general','Activo'),(37,'Cinta adhesiva 2\"','3M',NULL,'Productos de ferretería general','Activo'),(38,'Escalera de aluminio 6 pies','Werner',NULL,'Productos de ferretería general','Activo'),(39,'Pistola de silicona','Truper',NULL,'Productos de ferretería general','Activo'),(40,'Aceite multiusos 3 en 1','	WD-40','2027-02-02','Productos de ferretería general','Activo'),(41,'Lima triangular','Truper',NULL,'Herramientas manuales','Activo'),(42,'Martillo de goma','Stanley',NULL,'Herramientas manuales','Activo'),(43,'	Cortafrío','Pretul',NULL,'Herramientas manuales','Activo'),(44,'Extractor de rodamientos','Mikels',NULL,'Herramientas manuales','Activo'),(45,'Juego de llaves hexagonales','Urrea',NULL,'Herramientas manuales','Activo'),(46,'	Sierra de arco','Total Tools',NULL,'Herramientas manuales','Activo'),(47,'	Tenaza universal','Bellota',NULL,'Herramientas manuales','Activo'),(48,'	Juego de dados','Craftsman',NULL,'Herramientas manuales','Activo'),(49,'Cuchillo multiusos','Irwin',NULL,'Herramientas manuales','Activo'),(50,'Alicate pelacables','	Klein Tools',NULL,'Herramientas manuales','Activo'),(51,'Mango de repuesto para lima','Truper',NULL,'Herramientas manuales','Activo'),(52,'Compás de puntas','Bahco',NULL,'Herramientas manuales','Activo'),(53,'Pinzas para anillos','Jonnesway',NULL,'Herramientas manuales','Activo'),(54,'	Escofina para madera','Stanley',NULL,'Herramientas manuales','Activo'),(55,'Mango para segueta','Pretul',NULL,'Herramientas manuales','Activo'),(56,'	Taladro inalámbrico','Makita',NULL,'Herramientas eléctricas','Activo'),(57,'	Sierra circular','DeWalt',NULL,'Herramientas eléctricas','Activo'),(58,'Atornillador eléctrico','Bosch',NULL,'Herramientas eléctricas','Activo'),(59,'Multiherramienta rotativa','Dremel',NULL,'Herramientas eléctricas','Activo'),(60,'Pulidora angular','Total',NULL,'Herramientas eléctricas','Activo'),(61,'Lijadora de banda','Black+Decker',NULL,'Herramientas eléctricas','Activo'),(62,'	Cepillo eléctrico','Stanley',NULL,'Herramientas eléctricas','Activo'),(63,'Compresor portátil','Einhell',NULL,'Herramientas eléctricas','Activo'),(64,'	Sierra caladora','Ryobi',NULL,'Herramientas eléctricas','Activo'),(65,'Pistola de calor','Skill',NULL,'Herramientas eléctricas','Activo'),(66,'Amoladora de banco','Truper',NULL,'Herramientas eléctricas','Activo'),(67,'Taladro percutor','Bosch',NULL,'Herramientas eléctricas','Activo'),(68,'Destornillador a batería','Worx',NULL,'Herramientas eléctricas','Activo'),(69,'	Fresadora eléctrica','Makita',NULL,'Herramientas eléctricas','Activo'),(70,'Soldador inverter','Hyundai',NULL,'Herramientas eléctricas','Activo'),(71,'Juego de brocas 10pcs','Pretul',NULL,'Herramientas eléctricas','Activo'),(72,'Adhesivo industrial 1kg','UHU','2026-12-31','Productos de ferretería general','Activo'),(73,'Escoba de cerdas duras','Maped',NULL,'Productos de ferretería general','Activo'),(74,'Extensión eléctrica 5m','Truper',NULL,'Electricidad e iluminación','Activo'),(75,'Guantes de látex x100','3M','2025-11-30','Seguridad industrial','Activo'),(76,'Llave ajustable (76)','WD-40',NULL,'Materiales de construcción','Activo'),(77,'Destornillador de cruz (77)','Teflonex','2028-01-28','Seguridad industrial','Activo'),(78,'Sierra manual (78)','Total Tools',NULL,'Productos de ferretería general','Activo'),(79,'Martillo de bola (79)','Total Tools',NULL,'Tuberías y plomería','Activo'),(80,'Flexómetro 5m (80)','Teflonex',NULL,'Tuberías y plomería','Activo'),(81,'Rotomartillo (81)','Pretul',NULL,'Tuberías y plomería','Activo'),(82,'Sierra sable (82)','Stanley',NULL,'Herramientas eléctricas','Activo'),(83,'Esmeril angular (83)','Makita',NULL,'Tuberías y plomería','Activo'),(84,'Taladro inalámbrico (84)','Total Tools',NULL,'Materiales de construcción','Activo'),(85,'Soldador eléctrico (85)','Makita',NULL,'Materiales de construcción','Activo'),(86,'Cemento blanco 25kg (86)','Nicaplast',NULL,'Herramientas eléctricas','Activo'),(87,'Malla electrosoldada (87)','WD-40','2026-08-06','Herramientas manuales','Activo'),(88,'Arena volcánica m3 (88)','WD-40',NULL,'Herramientas eléctricas','Activo'),(89,'Ladrillo decorativo (89)','Stanley',NULL,'Materiales de construcción','Activo'),(90,'Pega para cerámica (90)','Truper','2026-07-22','Productos de ferretería general','Activo'),(91,'Pintura base agua 1gal (91)','Pretul','2026-03-16','Herramientas eléctricas','Activo'),(92,'Brocha angular 3\' (92)','Truper',NULL,'Electricidad e iluminación','Activo'),(93,'Cinta masking 2\' (93)','Total Tools',NULL,'Materiales de construcción','Activo'),(94,'Tubo PVC 3/4\' (94)','Bosch',NULL,'Electricidad e iluminación','Activo'),(95,'Grifo metálico 1/2\' (95)','3M',NULL,'Herramientas manuales','Activo'),(96,'Reducción PVC 1\' a 3/4\' (96)','WD-40',NULL,'Pinturas o accesorios','Activo'),(97,'Teflón industrial (97)','Nicaplast',NULL,'Herramientas manuales','Activo'),(98,'Interruptor doble (98)','Bosch',NULL,'Productos de ferretería general','Activo'),(99,'Toma corriente aterrizado (99)','Makita',NULL,'Herramientas manuales','Activo'),(100,'Alambre dúplex 14 (100)','Sur',NULL,'Materiales de construcción','Activo'),(101,'Martillo de acero forjado','Truper',NULL,'Herramientas manuales','Activo'),(102,'Botas dieléctricas (102)','Holcim',NULL,'Electricidad e iluminación','Activo'),(103,'Chaleco con cinta reflectiva (103)','Stanley',NULL,'Productos de ferretería general','Activo'),(104,'Casco tipo safari (104)','Makita',NULL,'Tuberías y plomería','Activo'),(105,'Gafas de seguridad antiempañante (105)','Dewalt',NULL,'Productos de ferretería general','Activo'),(106,'Escalera de fibra de vidrio (106)','Holcim',NULL,'Herramientas manuales','Activo'),(107,'Silicona negra 300ml (107)','Nicaplast',NULL,'Tuberías y plomería','Activo'),(108,'Trinche para jardín (108)','Dewalt',NULL,'Herramientas manuales','Activo'),(109,'Manguera reforzada 10m (109)','WD-40',NULL,'Electricidad e iluminación','Activo'),(110,'Cerradura de sobreponer (110)','3M','2027-07-02','Productos de ferretería general','Activo'),(111,'Candado de acero (111)','Sur',NULL,'Herramientas manuales','Activo'),(112,'Maneral de repuesto (112)','Truper','2025-12-12','Productos de ferretería general','Activo'),(113,'Tubo galvanizado 1\' (113)','Venusa',NULL,'Productos de ferretería general','Activo'),(114,'Tubo CPVC sanitario (114)','Stanley',NULL,'Materiales de construcción','Activo'),(115,'Caja de herramientas 16\' (115)','Truper',NULL,'Herramientas manuales','Activo'),(116,'Disco de corte 7\' (116)','Dewalt','2028-04-22','Materiales de construcción','Activo'),(117,'Multímetro digital (117)','3M',NULL,'Seguridad industrial','Activo'),(118,'Nivel de burbuja (118)','Pretul','2027-12-31','Pinturas o accesorios','Activo'),(119,'Clavos para concreto 2\' (119)','Makita',NULL,'Tuberías y plomería','Activo'),(120,'Pintura anticorrosiva 1gal (120)','3M',NULL,'Tuberías y plomería','Activo'),(121,'Espátula metálica (121)','Sur',NULL,'Pinturas o accesorios','Activo'),(122,'Pegamento de contacto (122)','Holcim',NULL,'Tuberías y plomería','Activo'),(123,'Sika impermeabilizante 4L (123)','Pretul','2028-02-17','Materiales de construcción','Activo'),(124,'Lija para madera (124)','Condumex','2025-12-26','Herramientas eléctricas','Activo'),(125,'Filtro para mascarilla (125)','Dewalt',NULL,'Herramientas eléctricas','Activo'),(126,'Pintura para techo (126)','WD-40',NULL,'Seguridad industrial','Activo'),(127,'Brocha para barniz (127)','Truper','2027-01-14','Electricidad e iluminación','Activo'),(128,'Tubo PVC sanitario 4\' (128)','Makita',NULL,'Productos de ferretería general','Activo'),(129,'Conector CPVC 1/2\' (129)','Teflonex',NULL,'Seguridad industrial','Activo'),(130,'Kit eléctrico básico (130)','Teflonex',NULL,'Materiales de construcción','Activo'),(131,'Codo galvanizado 1\' (131)','Stanley',NULL,'Tuberías y plomería','Activo'),(132,'Tubería PEX (132)','Holcim','2026-07-31','Pinturas o accesorios','Activo'),(133,'Cinta aislante negra (133)','Bosch',NULL,'Productos de ferretería general','Activo'),(134,'Kit de seguridad industrial (134)','Condumex','2025-12-25','Materiales de construcción','Activo'),(135,'Codo PVC sanitario 2\' (135)','Pretul',NULL,'Electricidad e iluminación','Activo'),(136,'Llave combinada 3/8\' (136)','Stanley',NULL,'Materiales de construcción','Activo'),(137,'Escuadra metálica (137)','Teflonex',NULL,'Electricidad e iluminación','Activo'),(138,'Martillo para carpintero (138)','Makita','2027-05-17','Productos de ferretería general','Activo'),(139,'Sierra caladora (139)','Teflonex',NULL,'Electricidad e iluminación','Activo'),(140,'Llave ajustable (140)','PAVCO',NULL,'Herramientas manuales','Activo'),(141,'Destornillador de cruz (141)','Bosch',NULL,'Productos de ferretería general','Activo'),(142,'Sierra manual (142)','3M',NULL,'Tuberías y plomería','Activo'),(143,'Martillo de bola (143)','Truper',NULL,'Herramientas eléctricas','Activo'),(144,'Flexómetro 5m (144)','Bosch',NULL,'Pinturas o accesorios','Activo'),(145,'Rotomartillo (145)','WD-40','2026-07-05','Materiales de construcción','Activo'),(146,'Sierra sable (146)','Condumex','2026-06-07','Materiales de construcción','Activo'),(147,'Esmeril angular (147)','PAVCO','2027-02-14','Herramientas eléctricas','Activo'),(148,'Taladro inalámbrico (148)','Nicaplast',NULL,'Materiales de construcción','Activo'),(149,'Soldador eléctrico (149)','Holcim',NULL,'Electricidad e iluminación','Activo'),(150,'Cemento blanco 25kg (150)','Truper','2027-12-30','Pinturas o accesorios','Activo'),(151,'Malla electrosoldada (151)','Teflonex','2026-06-17','Materiales de construcción','Activo'),(152,'Arena volcánica m3 (152)','3M','2028-03-14','Productos de ferretería general','Activo'),(153,'Ladrillo decorativo (153)','WD-40',NULL,'Herramientas eléctricas','Activo'),(154,'Pega para cerámica (154)','Teflonex',NULL,'Productos de ferretería general','Activo'),(155,'Pintura base agua 1gal (155)','Total Tools','2027-08-10','Electricidad e iluminación','Activo'),(156,'Brocha angular 3\' (156)','3M',NULL,'Tuberías y plomería','Activo'),(157,'Cinta masking 2\' (157)','Nicaplast',NULL,'Electricidad e iluminación','Activo'),(158,'Tubo PVC 3/4\' (158)','Makita','2027-02-23','Tuberías y plomería','Activo'),(159,'Grifo metálico 1/2\' (159)','Venusa','2026-10-29','Tuberías y plomería','Activo'),(160,'Reducción PVC 1\' a 3/4\' (160)','Condumex',NULL,'Productos de ferretería general','Activo'),(161,'Teflón industrial (161)','Holcim',NULL,'Seguridad industrial','Activo'),(162,'Interruptor doble (162)','Bosch','2027-04-24','Herramientas manuales','Activo'),(163,'Toma corriente aterrizado (163)','WD-40',NULL,'Herramientas eléctricas','Activo'),(164,'Alambre dúplex 14 (164)','3M',NULL,'Productos de ferretería general','Activo'),(165,'Foco LED 12W (165)','Venusa','2027-01-26','Herramientas manuales','Activo'),(166,'Botas dieléctricas (166)','Truper',NULL,'Electricidad e iluminación','Activo'),(167,'Chaleco con cinta reflectiva (167)','Nicaplast',NULL,'Herramientas manuales','Activo'),(168,'Casco tipo safari (168)','Pretul',NULL,'Tuberías y plomería','Activo'),(169,'Gafas de seguridad antiempañante (169)','Makita','2026-06-16','Tuberías y plomería','Activo'),(170,'Escalera de fibra de vidrio (170)','Venusa',NULL,'Seguridad industrial','Activo'),(171,'Silicona negra 300ml (171)','Condumex',NULL,'Productos de ferretería general','Activo'),(172,'Trinche para jardín (172)','WD-40',NULL,'Productos de ferretería general','Activo'),(173,'Manguera reforzada 10m (173)','Sur','2026-05-11','Herramientas manuales','Activo'),(174,'Cerradura de sobreponer (174)','Sur','2027-10-25','Productos de ferretería general','Activo'),(175,'Candado de acero (175)','Stanley',NULL,'Seguridad industrial','Activo'),(176,'Foco LED 12W (101)','Total Tools','2026-01-03','Herramientas manuales','Activo');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productventa`
--

DROP TABLE IF EXISTS `productventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productventa` (
  `Cod_Producto` int NOT NULL,
  `Cod_Venta` int NOT NULL,
  `Metodo_Pago` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Precio_Venta` float DEFAULT NULL,
  `Cantidad_Venta` float DEFAULT NULL,
  `Sector` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Fecha_salida` date DEFAULT NULL,
  PRIMARY KEY (`Cod_Venta`,`Cod_Producto`),
  KEY `Cod_Producto` (`Cod_Producto`),
  CONSTRAINT `productventa_ibfk_1` FOREIGN KEY (`Cod_Producto`) REFERENCES `producto` (`Cod_Producto`),
  CONSTRAINT `productventa_ibfk_2` FOREIGN KEY (`Cod_Venta`) REFERENCES `venta` (`Cod_Venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productventa`
--

LOCK TABLES `productventa` WRITE;
/*!40000 ALTER TABLE `productventa` DISABLE KEYS */;
INSERT INTO `productventa` VALUES (1,1,'Efectivo',312.5,10,'Herramientas manuales','2025-05-19'),(13,2,'Efectivo',437.5,15,'Materiales de construcción','2025-05-19'),(21,3,'Transferencia',56.25,3,'Tuberías y plomería','2025-05-19'),(18,4,'Efectivo',50,2,'Pinturas o accesorios','2025-05-19'),(19,4,'Efectivo',400,4,'Pinturas o accesorios','2025-05-19'),(7,5,'Transferencia',1812.5,1,'Herramientas eléctricas','2025-05-19'),(33,6,'Transferencia',75,3,'Seguridad industrial','2025-05-19'),(34,7,'Tarjeta',56.25,3,'Seguridad industrial','2025-05-19'),(31,8,'Tarjeta',175,8,'Seguridad industrial','2025-05-19'),(14,9,'Tarjeta',25,16,'Materiales de construcción','2025-05-19'),(27,10,'Transferencia',31.25,5,'Electricidad e iluminación','2025-05-19'),(12,11,'Tarjeta',225,5,'Materiales de construcción','2025-05-19'),(7,12,'Efectivo',1812.5,2,'Herramientas eléctricas','2025-05-19');
/*!40000 ALTER TABLE `productventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor` (
  `Cod_Proveedor` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Sector` varchar(50) DEFAULT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT NULL,
  PRIMARY KEY (`Cod_Proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,'Jorge','Mendez','Herramientas manuales','Activo'),(2,'Carla','Ruiz','Herramientas manuales','Activo'),(3,'Mario','Torres','Herramientas eléctricas','Activo'),(4,'Elena','Cordero','Herramientas eléctricas','Activo'),(5,'Luis','Gonzales','Materiales de construcción','Activo'),(6,'Mariela','Perez','Materiales de construcción','Activo'),(7,'Ana','Morales','Pinturas o accesorios','Activo'),(8,'Diego','Castillo','Pinturas o accesorios','Activo'),(9,'Roberto','Salgado','Tuberías y plomería','Activo'),(10,'Gabriela','Molina','Tuberías y plomería','Activo'),(11,'Carlos','Navarro','Electricidad e iluminación','Activo'),(12,'Ingrid','Lopez','Electricidad e iluminación','Activo'),(13,'Fernando','Reyes','Seguridad industrial','Activo'),(14,'Patricia','Duarte','Seguridad industrial','Activo'),(15,'Esteban','Rivas','Productos de ferretería general','Activo'),(16,'Julia','Campos','Productos de ferretería general','Activo');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveproduct`
--

DROP TABLE IF EXISTS `proveproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveproduct` (
  `Cod_Proveedor` int NOT NULL,
  `Cod_Producto` int NOT NULL,
  `Fecha_Entrada` date DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  `Cantidad` int DEFAULT NULL,
  PRIMARY KEY (`Cod_Proveedor`,`Cod_Producto`),
  KEY `Cod_Producto` (`Cod_Producto`),
  CONSTRAINT `proveproduct_ibfk_1` FOREIGN KEY (`Cod_Proveedor`) REFERENCES `proveedor` (`Cod_Proveedor`),
  CONSTRAINT `proveproduct_ibfk_2` FOREIGN KEY (`Cod_Producto`) REFERENCES `producto` (`Cod_Producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveproduct`
--

LOCK TABLES `proveproduct` WRITE;
/*!40000 ALTER TABLE `proveproduct` DISABLE KEYS */;
INSERT INTO `proveproduct` VALUES (1,1,'2025-05-17',250,30),(1,4,'2025-05-17',220,33),(1,41,'2025-05-19',85,12),(1,42,'2025-05-19',130,10),(1,43,'2025-05-19',95,15),(1,44,'2025-05-19',320,10),(1,45,'2025-05-19',150,10),(1,46,'2025-05-19',190,10),(1,47,'2025-05-19',110,20),(1,48,'2025-05-19',450,10),(1,49,'2025-05-19',75,15),(1,50,'2025-05-19',145,15),(1,51,'2025-05-19',25,20),(1,52,'2025-05-19',165,5),(1,53,'2025-05-19',195,10),(1,54,'2025-05-19',120,10),(1,55,'2025-05-19',60,16),(1,87,'2025-05-19',542.75,177),(1,95,'2025-05-19',320.18,109),(1,97,'2025-05-19',220,21),(1,99,'2025-05-19',61.26,160),(1,101,'2025-05-19',1000,30),(1,106,'2025-05-19',298.69,190),(1,108,'2025-05-19',247.71,107),(1,111,'2025-05-19',233.41,78),(1,115,'2025-05-19',28.19,58),(1,140,'2025-05-19',443.94,34),(1,162,'2025-05-19',441.96,17),(1,165,'2025-05-19',162.02,172),(1,167,'2025-05-19',29.42,160),(1,173,'2025-05-19',226.57,10),(1,176,'2025-05-19',458.17,74),(2,2,'2025-05-17',300,18),(2,3,'2025-05-17',180,11),(2,5,'2025-05-17',990,60),(3,6,'2025-05-17',1100,19),(3,7,'2025-05-17',1450,5),(3,8,'2025-05-17',990,12),(3,56,'2025-05-19',1850,10),(3,57,'2025-05-19',2150,5),(3,58,'2025-05-19',970,10),(3,59,'2025-05-19',1300,10),(3,60,'2025-05-19',1600,15),(3,61,'2025-05-19',1950,20),(3,62,'2025-05-19',1800,10),(3,63,'2025-05-19',2900,15),(3,71,'2025-05-19',240,18),(3,82,'2025-05-19',379.03,36),(3,86,'2025-05-19',479.22,21),(3,88,'2025-05-19',116.33,136),(3,91,'2025-05-19',372.43,193),(3,124,'2025-05-19',184.2,85),(3,125,'2025-05-19',527.6,141),(3,143,'2025-05-19',535.05,141),(3,147,'2025-05-19',306.38,41),(3,153,'2025-05-19',100.82,169),(3,163,'2025-05-19',202.25,51),(4,9,'2025-05-17',1050,11),(4,10,'2025-05-17',1600,8),(4,64,'2025-05-19',1350,14),(4,65,'2025-05-19',670,20),(4,66,'2025-05-19',2100,15),(4,67,'2025-05-19',2400,15),(4,68,'2025-05-19',820,16),(4,69,'2025-05-19',2300,15),(4,70,'2025-05-19',3700,10),(5,11,'2025-05-17',208,150),(5,12,'2025-05-17',180,90),(5,13,'2025-05-17',350,2),(5,76,'2025-05-19',367.4,66),(5,84,'2025-05-19',263.51,48),(5,85,'2025-05-19',550.52,29),(5,89,'2025-05-19',151.39,185),(5,93,'2025-05-19',239.06,116),(5,100,'2025-05-19',520.54,152),(5,114,'2025-05-19',105.34,140),(5,116,'2025-05-19',360.84,10),(5,123,'2025-05-19',526.99,161),(5,130,'2025-05-19',171.4,43),(5,134,'2025-05-19',135.97,192),(5,136,'2025-05-19',151.43,22),(5,145,'2025-05-19',275.93,75),(5,146,'2025-05-19',88.69,169),(5,148,'2025-05-19',50.93,90),(5,151,'2025-05-19',48.67,191),(6,14,'2025-05-17',20,374),(6,15,'2025-05-17',23,60),(7,16,'2025-05-18',280,33),(7,17,'2025-05-18',90,46),(7,18,'2025-05-18',40,98),(7,19,'2025-05-18',320,16),(7,96,'2025-05-19',423.4,76),(7,118,'2025-05-19',165.9,105),(7,121,'2025-05-19',390.9,58),(7,132,'2025-05-19',72.75,43),(7,144,'2025-05-19',286.32,38),(7,150,'2025-05-19',293.78,108),(8,20,'2025-05-18',95,25),(9,21,'2025-05-18',45,117),(9,22,'2025-05-18',60,90),(9,79,'2025-05-19',322.37,58),(9,80,'2025-05-19',418.09,49),(9,81,'2025-05-19',76.4,124),(9,83,'2025-05-19',457.1,106),(9,104,'2025-05-19',391.69,96),(9,107,'2025-05-19',49.84,130),(9,119,'2025-05-19',85.11,189),(9,120,'2025-05-19',582.17,186),(9,122,'2025-05-19',491.37,10),(9,131,'2025-05-19',594.8,26),(9,142,'2025-05-19',583.21,57),(9,156,'2025-05-19',425.97,121),(9,158,'2025-05-19',524.66,54),(9,159,'2025-05-19',340.25,136),(9,168,'2025-05-19',27.86,102),(9,169,'2025-05-19',246.46,43),(10,23,'2025-05-18',15,200),(10,24,'2025-05-18',12,250),(10,25,'2025-05-18',35,40),(11,26,'2025-05-18',35,150),(11,27,'2025-05-18',25,115),(11,74,'2025-05-19',90,30),(11,92,'2025-05-19',576.33,65),(11,94,'2025-05-19',73.75,156),(11,102,'2025-05-19',34.44,136),(11,109,'2025-05-19',400.16,194),(11,127,'2025-05-19',539.31,23),(11,135,'2025-05-19',27.29,195),(11,137,'2025-05-19',265.79,100),(11,139,'2025-05-19',180.46,38),(11,149,'2025-05-19',568.43,86),(11,155,'2025-05-19',247.67,16),(11,157,'2025-05-19',196.36,80),(11,166,'2025-05-19',347.97,178),(12,28,'2025-05-18',18,500),(12,29,'2025-05-18',22,180),(12,30,'2025-05-18',290,35),(13,31,'2025-05-18',140,52),(13,32,'2025-05-18',85,96),(13,33,'2025-05-18',60,86),(13,75,'2025-05-19',65,50),(13,77,'2025-05-19',211.51,60),(13,117,'2025-05-19',362.61,115),(13,126,'2025-05-19',492.74,124),(13,129,'2025-05-19',255.23,136),(13,161,'2025-05-19',489.39,142),(13,170,'2025-05-19',587.23,185),(13,175,'2025-05-19',186.29,164),(14,34,'2025-05-18',45,191),(14,35,'2025-05-18',75,120),(15,36,'2025-05-18',60,80),(15,37,'2025-05-18',35,100),(15,38,'2025-05-18',980,10),(15,39,'2025-05-18',120,50),(15,40,'2025-05-18',85,70),(15,72,'2025-05-19',135,25),(15,73,'2025-05-19',45,40),(15,78,'2025-05-19',578,166),(15,90,'2025-05-19',568.07,114),(15,98,'2025-05-19',315.5,36),(15,103,'2025-05-19',505.9,95),(15,105,'2025-05-19',81.6,170),(15,110,'2025-05-19',563.49,33),(15,112,'2025-05-19',115.25,163),(15,113,'2025-05-19',89.5,56),(15,128,'2025-05-19',47.76,198),(15,133,'2025-05-19',58.57,68),(15,138,'2025-05-19',521.74,192),(15,141,'2025-05-19',586.39,66),(15,152,'2025-05-19',231.86,37),(15,154,'2025-05-19',228.83,60),(15,160,'2025-05-19',467.83,127),(15,164,'2025-05-19',571.16,124),(15,171,'2025-05-19',548.18,22),(15,172,'2025-05-19',342.1,194),(15,174,'2025-05-19',194,33);
/*!40000 ALTER TABLE `proveproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('wpnDNVtA-y2CGBlWsqzGm1LPo9IPitfA',1747799072,'{\"cookie\":{\"originalMaxAge\":86400000,\"expires\":\"2025-05-21T03:41:43.294Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"passport\":{\"user\":1},\"flash\":{}}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telefono`
--

DROP TABLE IF EXISTS `telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telefono` (
  `Numero` varchar(9) NOT NULL,
  `Compania` varchar(50) NOT NULL,
  `Cod_Proveedor` int DEFAULT NULL,
  `Cod_Empleado` int DEFAULT NULL,
  PRIMARY KEY (`Numero`),
  KEY `Cod_Proveedor` (`Cod_Proveedor`),
  KEY `Cod_Empleado` (`Cod_Empleado`),
  CONSTRAINT `telefono_ibfk_1` FOREIGN KEY (`Cod_Proveedor`) REFERENCES `proveedor` (`Cod_Proveedor`),
  CONSTRAINT `telefono_ibfk_2` FOREIGN KEY (`Cod_Empleado`) REFERENCES `empleado` (`Cod_Empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telefono`
--

LOCK TABLES `telefono` WRITE;
/*!40000 ALTER TABLE `telefono` DISABLE KEYS */;
INSERT INTO `telefono` VALUES ('123456780','Tigo',NULL,1),('65253412','Claro',NULL,4),('77955356','Tigo',NULL,3),('78789898','Claro',NULL,5),('81825567','Claro',15,NULL),('81902288','Claro',10,NULL),('83214455','Claro',13,NULL),('83456678','Claro',4,NULL),('84125513','Tigo',7,NULL),('84321023','Claro',14,NULL),('84832210','Tigo',1,NULL),('85207784','Tigo',8,NULL),('85679012','Tigo',2,NULL),('85843310','Claro',16,NULL),('85904321','Claro',5,NULL),('86439087','Claro',12,NULL),('87031199','Claro',6,NULL),('87535453','Tigo',NULL,2),('87556666','Claro',11,NULL),('87891200','Claro',3,NULL),('88763211','Claro',9,NULL);
/*!40000 ALTER TABLE `telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `Cod_Venta` int NOT NULL AUTO_INCREMENT,
  `Estado_Venta` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Cod_Empleado` int DEFAULT NULL,
  PRIMARY KEY (`Cod_Venta`),
  KEY `Cod_Empleado` (`Cod_Empleado`),
  CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`Cod_Empleado`) REFERENCES `empleado` (`Cod_Empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (1,'Completada',1),(2,'Completada',1),(3,'Completada',2),(4,'Completada',3),(5,'Completada',3),(6,'Completada',4),(7,'Completada',4),(8,'Completada',5),(9,'Completada',5),(10,'Completada',5),(11,'Completada',1),(12,'Completada',1);
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ferreteria'
--

--
-- Dumping routines for database 'ferreteria'
--
/*!50003 DROP PROCEDURE IF EXISTS `ReporteProductosVendidos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `ReporteProductosVendidos`()
BEGIN
    -- Eliminar si existen
    DROP TEMPORARY TABLE IF EXISTS TempReporte;
    DROP TEMPORARY TABLE IF EXISTS TempVentasProductos;
    DROP TEMPORARY TABLE IF EXISTS TempMasVendidos;

    -- Crear tabla temporal para todos los productos vendidos con sus cantidades
    CREATE TEMPORARY TABLE TempVentasProductos (
        Cod_Producto VARCHAR(50),
        Nombre VARCHAR(100),
        CantidadVendida INT
    );

    -- Insertar todos los productos vendidos con sus cantidades
    INSERT INTO TempVentasProductos (Cod_Producto, Nombre, CantidadVendida)
    SELECT 
        P.Cod_Producto, 
        P.Nombre, 
        COALESCE(SUM(PV.Cantidad_Venta), 0) AS CantidadVendida
    FROM Producto P
    LEFT JOIN ProductVenta PV ON P.Cod_Producto = PV.Cod_Producto
    LEFT JOIN Venta V ON PV.Cod_Venta = V.Cod_Venta AND V.Estado_Venta = 'Finalizada'
    GROUP BY P.Cod_Producto, P.Nombre;

    -- Crear tabla para el reporte final
    CREATE TEMPORARY TABLE TempReporte (
        Cod_Producto VARCHAR(50),
        Nombre VARCHAR(100),
        CantidadVendida INT,
        Tipo VARCHAR(20)
    );

    -- Tabla temporal para los más vendidos
    CREATE TEMPORARY TABLE TempMasVendidos (
        Cod_Producto VARCHAR(50)
    );

    -- Insertar productos más vendidos (Top 5 con cantidad de ventas más alta)
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto, 
        Nombre, 
        CantidadVendida,
        'Mas Vendido' AS Tipo
    FROM TempVentasProductos
    WHERE CantidadVendida > 0
    ORDER BY CantidadVendida DESC
    LIMIT 5;

    -- Guardar los códigos de los más vendidos
    INSERT INTO TempMasVendidos (Cod_Producto)
    SELECT Cod_Producto FROM TempReporte WHERE Tipo = 'Mas Vendido';

    -- Insertar productos menos vendidos (excluyendo los más vendidos)
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto,
        Nombre,
        CantidadVendida,
        'Menos Vendido' AS Tipo
    FROM TempVentasProductos
    WHERE CantidadVendida > 0
      AND Cod_Producto NOT IN (SELECT Cod_Producto FROM TempMasVendidos)
    ORDER BY CantidadVendida ASC
    LIMIT 5;

    -- Insertar productos no vendidos
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto,
        Nombre,
        0,
        'No Vendido'
    FROM TempVentasProductos
    WHERE CantidadVendida = 0;

    -- Mostrar resultado consolidado
    SELECT * FROM TempReporte
    ORDER BY 
        CASE Tipo
            WHEN 'Mas Vendido' THEN 1
            WHEN 'Menos Vendido' THEN 2
            WHEN 'No Vendido' THEN 3
        END,
        CASE WHEN Tipo = 'Menos Vendido' THEN CantidadVendida ELSE -CantidadVendida END;

    -- Limpieza
    DROP TEMPORARY TABLE IF EXISTS TempMasVendidos;
    DROP TEMPORARY TABLE IF EXISTS TempVentasProductos;
    DROP TEMPORARY TABLE IF EXISTS TempReporte;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ResetPasswordToDefault` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `ResetPasswordToDefault`(IN emp_id INT)
BEGIN
    -- Declarar variable para la contraseña temporal
    DECLARE default_pass VARCHAR(255);
    
    -- Este es un hash de ejemplo para '1234'
    SET default_pass = '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrYV8LJ2JmspXb6X3JQ0QjRXU9J7WnK';
    
    -- Actualizar la contraseña
    UPDATE Empleado 
    SET Contraseña = default_pass
    WHERE Cod_Empleado = emp_id;
    
    -- Devolver el número de filas afectadas
    SELECT ROW_COUNT() AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_bodega` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `sp_reporte_bodega`(
    IN sector_param VARCHAR(50),
    IN periodo_param VARCHAR(10),
    IN search_term VARCHAR(100)
)
BEGIN
    -- Variables para condiciones dinámicas
    DECLARE sector_condition VARCHAR(200) DEFAULT '';
    DECLARE periodo_condition VARCHAR(200) DEFAULT '';
    DECLARE search_condition VARCHAR(200) DEFAULT '';
    
    -- Construir condición para sector (solo si se proporciona)
    IF sector_param IS NOT NULL AND sector_param != '' THEN
        SET sector_condition = CONCAT(' AND p.Sector = "', sector_param, '"');
    END IF;
    
    -- Construir condición para período (incluso si es 'todos')
    IF periodo_param IS NOT NULL THEN
        CASE periodo_param
            WHEN 'diario' THEN SET periodo_condition = ' AND pp.Fecha_Entrada >= DATE_SUB(CURDATE(), INTERVAL 1 DAY)';
            WHEN 'semanal' THEN SET periodo_condition = ' AND pp.Fecha_Entrada >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
            WHEN 'mensual' THEN SET periodo_condition = ' AND pp.Fecha_Entrada >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)';
            WHEN 'todos' THEN SET periodo_condition = ''; -- No filtrar por fecha
        END CASE;
    END IF;
    
    -- Construir condición para término de búsqueda
    IF search_term IS NOT NULL AND search_term != '' THEN
        SET search_condition = CONCAT(' AND (p.Nombre LIKE "%', search_term, '%" OR p.Cod_Producto LIKE "%', search_term, '%")');
    END IF;
    
    -- Consulta principal con condiciones dinámicas
    SET @sql = CONCAT('
        SELECT 
            p.Cod_Producto,
            p.Nombre,
            p.Marca,
            pp.Fecha_Entrada AS FechaEntrada,
            pp.Cantidad,
            p.FechaVencimiento,
            p.Sector
        FROM 
            Producto p
        JOIN 
            ProveProduct pp ON p.Cod_Producto = pp.Cod_Producto
        WHERE 
            p.Estado = "Activo"',
            sector_condition,
            periodo_condition,
            search_condition,
        ' ORDER BY pp.Fecha_Entrada DESC');
    
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_ventas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `sp_reporte_ventas`(
    IN filtro VARCHAR(10)
)
BEGIN
    SELECT 
        v.Cod_Venta,
        pv.Cod_Producto,
        p.Nombre AS Nombre_Producto,
        ROUND(SUM(pv.Precio_Venta * pv.Cantidad_Venta), 2) AS Monto_Total,
        pv.Fecha_salida AS Fecha_Venta
    FROM 
        Venta v
    JOIN 
        ProductVenta pv ON v.Cod_Venta = pv.Cod_Venta
    JOIN 
        Producto p ON p.Cod_Producto = pv.Cod_Producto
    WHERE
        (filtro = 'diario' AND pv.Fecha_salida >= CURDATE() - INTERVAL 1 DAY)
        OR (filtro = 'semanal' AND pv.Fecha_salida >= CURDATE() - INTERVAL 7 DAY)
        OR (filtro = 'mensual' AND pv.Fecha_salida >= CURDATE() - INTERVAL 1 MONTH)
    GROUP BY 
        v.Cod_Venta, pv.Cod_Producto, p.Nombre, pv.Fecha_salida;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-19 21:47:37
