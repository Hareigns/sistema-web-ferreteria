-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ferreteria
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `Cod_Empleado` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Direccion` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT NULL,
  `FechaIngreso` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Cedula` varchar(14) DEFAULT NULL,
  `Contraseña` varchar(255) DEFAULT '1234',
  PRIMARY KEY (`Cod_Empleado`),
  CONSTRAINT `CHK_Cedula_Formato` CHECK (regexp_like(`Cedula`,_utf8mb4'^[0-9]{13}[A-Z]$'))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,'Luis','Torres','Barrio San Luis','Activo','2025-05-05 21:37:54','0012304561234A','$2b$10$nrKUIwz5qNlyBGI7eI3ceeb.mWWIwyxNAaJnOrbJBYN/MBdEzDItq'),(2,'Sofia','Alvarado','Colonial Luis','Activo','2025-05-18 03:19:26','0012610001030Y','$2b$10$bNDzrRXNy/oelBCtKlkz5OcmJ381lglaunwoHYZsWpAE2ltsQnGWG'),(3,'Jorge','Mendez','Barrio San Luis','Activo','2025-05-18 03:20:12','0013001972015Q','$2b$10$Zi5pN4H7xth4RLeCA2Uxs.lDiLYjsY8gK42yVjKPwuNO.6tLqP5kC'),(4,'Maria','Juarez','Barrio San Sebastian','Activo','2025-05-19 05:26:38','1112512983033M','$2b$10$z6vxc6Aqp6edbw4o.VFia.HhE2ae0hMAt/ABTDtw/La1sGh2ICzAy'),(5,'Paulo','Rivera','Barrio San Luis','Activo','2025-05-19 05:27:57','1810906954411J','$2b$10$k69KcY5u1WcPQ5Hxwzf0be/CFEOKphckPvbxg0vpi.fIC4W8vg/Fm');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `Cod_Producto` int NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Marca` varchar(50) DEFAULT NULL,
  `FechaVencimiento` date DEFAULT NULL,
  `Sector` varchar(50) DEFAULT NULL,
  `Estado` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'Activo',
  PRIMARY KEY (`Cod_Producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Llave Inglesa 10\"','Truper',NULL,'Herramientas manuales','Activo'),(2,'Juego de destornilladores','	Stanley',NULL,'Herramientas manuales','Activo'),(3,'Serrucho manual','	Bellota',NULL,'Herramientas manuales','Activo'),(4,'	Martillo carpintero','	Pretul',NULL,'Herramientas manuales','Activo'),(5,'	Cinta métrica 5m','Truper',NULL,'Herramientas manuales','Activo'),(6,'	Taladro percutor','	Bosch',NULL,'Herramientas eléctricas','Activo'),(7,'	Sierra circular 7\"','	Makita',NULL,'Herramientas eléctricas','Activo'),(8,'Pulidora angular','	Dewalt',NULL,'Herramientas eléctricas','Activo'),(9,'	Caladora eléctrica','	Black+Decker',NULL,'Herramientas eléctricas','Activo'),(10,'	Soldador inverter','	Koblenz',NULL,'Herramientas eléctricas','Activo'),(11,'	Bolsa de cemento 42.5kg','Holcim','2025-05-17','Materiales de construcción','Activo'),(12,'Varilla corrugada 3/8\"','	Aceros',NULL,'Materiales de construcción','Activo'),(13,'Arena fina m3','NicaMateriales',NULL,'Materiales de construcción','Activo'),(14,'Bloque de concreto','	Durabloque',NULL,'Materiales de construcción','Activo'),(15,'Mortero seco','Cemex','2025-05-23','Materiales de construcción','Activo'),(16,'Pintura látex blanco 1gal','Sur','2025-06-28','Pinturas o accesorios','Activo'),(17,'Rodillo para pintar','Truper',NULL,'Pinturas o accesorios','Activo'),(18,'Brocha 2\"','Venusa',NULL,'Pinturas o accesorios','Activo'),(19,'	Pintura esmalte negro 1gal','Lanco','2027-06-18','Pinturas o accesorios','Activo'),(20,'Diluyente 1lt','Solven','2025-12-25','Pinturas o accesorios','Activo'),(21,'Tubería PVC 1/2\" x 3m','	Nicaplast',NULL,'Tuberías y plomería','Activo'),(22,'Llave de paso 1/2\"','PAVCO',NULL,'Tuberías y plomería','Activo'),(23,'Conector PVC 3/4\"','	Nicaplast',NULL,'Tuberías y plomería','Activo'),(24,'	Cinta teflón','Teflonex',NULL,'Tuberías y plomería','Activo'),(25,'Pegamento para PVC 125ml','Pegafix','2025-10-17','Tuberías y plomería','Activo'),(26,'Bombillo LED 9W','Philips',NULL,'Electricidad e iluminación','Activo'),(27,'Tomacorriente doble','Bticino',NULL,'Electricidad e iluminación','Activo'),(28,'Cable THHN 12 AWG x metro','Condumex',NULL,'Electricidad e iluminación','Activo'),(29,'Interruptor sencillo','	Bticino',NULL,'Electricidad e iluminación','Activo'),(30,'Lámpara LED 60cm','Osram',NULL,'Electricidad e iluminación','Activo'),(31,'Casco de seguridad','3M',NULL,'Seguridad industrial','Activo'),(32,'Chaleco reflectivo','MSA',NULL,'Seguridad industrial','Activo'),(33,'Lentes de protección','Venprotex',NULL,'Seguridad industrial','Activo'),(34,'	Mascarilla N95','3M','2025-07-18','Seguridad industrial','Activo'),(35,'Guantes de cuero','Dexter',NULL,'Seguridad industrial','Activo'),(36,'Silicona transparente 280ml','	Sista','2026-06-09','Productos de ferretería general','Activo'),(37,'Cinta adhesiva 2\"','3M',NULL,'Productos de ferretería general','Activo'),(38,'Escalera de aluminio 6 pies','Werner',NULL,'Productos de ferretería general','Activo'),(39,'Pistola de silicona','Truper',NULL,'Productos de ferretería general','Activo'),(40,'Aceite multiusos 3 en 1','	WD-40','2027-02-02','Productos de ferretería general','Activo');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productventa`
--

DROP TABLE IF EXISTS `productventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productventa` (
  `Cod_Producto` int NOT NULL,
  `Cod_Venta` int NOT NULL,
  `Metodo_Pago` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Precio_Venta` float DEFAULT NULL,
  `Cantidad_Venta` float DEFAULT NULL,
  `Sector` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Fecha_salida` date DEFAULT NULL,
  PRIMARY KEY (`Cod_Venta`,`Cod_Producto`),
  KEY `Cod_Producto` (`Cod_Producto`),
  CONSTRAINT `productventa_ibfk_1` FOREIGN KEY (`Cod_Producto`) REFERENCES `producto` (`Cod_Producto`),
  CONSTRAINT `productventa_ibfk_2` FOREIGN KEY (`Cod_Venta`) REFERENCES `venta` (`Cod_Venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productventa`
--

LOCK TABLES `productventa` WRITE;
/*!40000 ALTER TABLE `productventa` DISABLE KEYS */;
INSERT INTO `productventa` VALUES (1,1,'Efectivo',312.5,10,'Herramientas manuales','2025-05-19'),(13,2,'Efectivo',437.5,15,'Materiales de construcción','2025-05-19'),(21,3,'Transferencia',56.25,3,'Tuberías y plomería','2025-05-19'),(18,4,'Efectivo',50,2,'Pinturas o accesorios','2025-05-19'),(19,4,'Efectivo',400,4,'Pinturas o accesorios','2025-05-19'),(7,5,'Transferencia',1812.5,1,'Herramientas eléctricas','2025-05-19'),(33,6,'Transferencia',75,3,'Seguridad industrial','2025-05-19'),(34,7,'Tarjeta',56.25,3,'Seguridad industrial','2025-05-19'),(31,8,'Tarjeta',175,8,'Seguridad industrial','2025-05-19'),(14,9,'Tarjeta',25,16,'Materiales de construcción','2025-05-19'),(27,10,'Transferencia',31.25,5,'Electricidad e iluminación','2025-05-19');
/*!40000 ALTER TABLE `productventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor` (
  `Cod_Proveedor` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Sector` varchar(50) DEFAULT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT NULL,
  PRIMARY KEY (`Cod_Proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,'Jorge','Mendez','Herramientas manuales','Activo'),(2,'Carla','Ruiz','Herramientas manuales','Activo'),(3,'Mario','Torres','Herramientas eléctricas','Activo'),(4,'Elena','Cordero','Herramientas eléctricas','Activo'),(5,'Luis','Gonzales','Materiales de construcción','Activo'),(6,'Mariela','Perez','Materiales de construcción','Activo'),(7,'Ana','Morales','Pinturas o accesorios','Activo'),(8,'Diego','Castillo','Pinturas o accesorios','Activo'),(9,'Roberto','Salgado','Tuberías y plomería','Activo'),(10,'Gabriela','Molina','Tuberías y plomería','Activo'),(11,'Carlos','Navarro','Electricidad e iluminación','Activo'),(12,'Ingrid','Lopez','Electricidad e iluminación','Activo'),(13,'Fernando','Reyes','Seguridad industrial','Activo'),(14,'Patricia','Duarte','Seguridad industrial','Activo'),(15,'Esteban','Rivas','Productos de ferretería general','Activo'),(16,'Julia','Campos','Productos de ferretería general','Activo');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveproduct`
--

DROP TABLE IF EXISTS `proveproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveproduct` (
  `Cod_Proveedor` int NOT NULL,
  `Cod_Producto` int NOT NULL,
  `Fecha_Entrada` date DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  `Cantidad` int DEFAULT NULL,
  PRIMARY KEY (`Cod_Proveedor`,`Cod_Producto`),
  KEY `Cod_Producto` (`Cod_Producto`),
  CONSTRAINT `proveproduct_ibfk_1` FOREIGN KEY (`Cod_Proveedor`) REFERENCES `proveedor` (`Cod_Proveedor`),
  CONSTRAINT `proveproduct_ibfk_2` FOREIGN KEY (`Cod_Producto`) REFERENCES `producto` (`Cod_Producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveproduct`
--

LOCK TABLES `proveproduct` WRITE;
/*!40000 ALTER TABLE `proveproduct` DISABLE KEYS */;
INSERT INTO `proveproduct` VALUES (1,1,'2025-05-17',250,30),(1,4,'2025-05-17',220,33),(2,2,'2025-05-17',300,18),(2,3,'2025-05-17',180,11),(2,5,'2025-05-17',990,60),(3,6,'2025-05-17',1100,19),(3,7,'2025-05-17',1450,7),(3,8,'2025-05-17',990,12),(4,9,'2025-05-17',1050,11),(4,10,'2025-05-17',1600,8),(5,11,'2025-05-17',208,150),(5,12,'2025-05-17',180,95),(5,13,'2025-05-17',350,2),(6,14,'2025-05-17',20,374),(6,15,'2025-05-17',23,60),(7,16,'2025-05-18',280,33),(7,17,'2025-05-18',90,46),(7,18,'2025-05-18',40,98),(7,19,'2025-05-18',320,16),(8,20,'2025-05-18',95,25),(9,21,'2025-05-18',45,117),(9,22,'2025-05-18',60,90),(10,23,'2025-05-18',15,200),(10,24,'2025-05-18',12,250),(10,25,'2025-05-18',35,40),(11,26,'2025-05-18',35,150),(11,27,'2025-05-18',25,115),(12,28,'2025-05-18',18,500),(12,29,'2025-05-18',22,180),(12,30,'2025-05-18',290,35),(13,31,'2025-05-18',140,52),(13,32,'2025-05-18',85,96),(13,33,'2025-05-18',60,86),(14,34,'2025-05-18',45,191),(14,35,'2025-05-18',75,120),(15,36,'2025-05-18',60,80),(15,37,'2025-05-18',35,100),(15,38,'2025-05-18',980,10),(15,39,'2025-05-18',120,50),(15,40,'2025-05-18',85,70);
/*!40000 ALTER TABLE `proveproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('-AR4UWy7Vw0JsdtEDO6svwALx0Vu_s27',1747706927,'{\"cookie\":{\"originalMaxAge\":86400000,\"expires\":\"2025-05-20T02:08:47.396Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"flash\":{}}'),('FchO76UDmdjw2ajnDRULnoeHZAfcUohu',1747711097,'{\"cookie\":{\"originalMaxAge\":86400000,\"expires\":\"2025-05-20T03:18:16.769Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"flash\":{}}'),('ZUHeuUxwes5fvXdTvtz5QUWofObpuA1O',1747706927,'{\"cookie\":{\"originalMaxAge\":86400000,\"expires\":\"2025-05-20T02:08:47.459Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"flash\":{}}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telefono`
--

DROP TABLE IF EXISTS `telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telefono` (
  `Numero` varchar(9) NOT NULL,
  `Compania` varchar(50) NOT NULL,
  `Cod_Proveedor` int DEFAULT NULL,
  `Cod_Empleado` int DEFAULT NULL,
  PRIMARY KEY (`Numero`),
  KEY `Cod_Proveedor` (`Cod_Proveedor`),
  KEY `Cod_Empleado` (`Cod_Empleado`),
  CONSTRAINT `telefono_ibfk_1` FOREIGN KEY (`Cod_Proveedor`) REFERENCES `proveedor` (`Cod_Proveedor`),
  CONSTRAINT `telefono_ibfk_2` FOREIGN KEY (`Cod_Empleado`) REFERENCES `empleado` (`Cod_Empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telefono`
--

LOCK TABLES `telefono` WRITE;
/*!40000 ALTER TABLE `telefono` DISABLE KEYS */;
INSERT INTO `telefono` VALUES ('123456780','Tigo',NULL,1),('84832210','Tigo',1,NULL),('85207784','Tigo',8,NULL),('85679012','Tigo',2,NULL),('85843310','Claro',16,NULL),('85904321','Claro',5,NULL),('86439087','Claro',12,NULL),('87031199','Claro',6,NULL),('87535453','Tigo',NULL,2),('87556666','Claro',11,NULL),('87891200','Claro',3,NULL),('88763211','Claro',9,NULL);
/*!40000 ALTER TABLE `telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `Cod_Venta` int NOT NULL AUTO_INCREMENT,
  `Estado_Venta` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Cod_Empleado` int DEFAULT NULL,
  PRIMARY KEY (`Cod_Venta`),
  KEY `Cod_Empleado` (`Cod_Empleado`),
  CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`Cod_Empleado`) REFERENCES `empleado` (`Cod_Empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (1,'Completada',1),(2,'Completada',1),(3,'Completada',2),(4,'Completada',3),(5,'Completada',3),(6,'Completada',4),(7,'Completada',4),(8,'Completada',5),(9,'Completada',5),(10,'Completada',5);
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ferreteria'
--

--
-- Dumping routines for database 'ferreteria'
--
/*!50003 DROP PROCEDURE IF EXISTS `ReporteProductosVendidos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `ReporteProductosVendidos`()
BEGIN
    
    DROP TEMPORARY TABLE IF EXISTS TempReporte;
    DROP TEMPORARY TABLE IF EXISTS TempVentasProductos;
    DROP TEMPORARY TABLE IF EXISTS TempMasVendidos;

    
    CREATE TEMPORARY TABLE TempVentasProductos (
        Cod_Producto VARCHAR(50),
        Nombre VARCHAR(100),
        CantidadVendida INT
    );

    
    INSERT INTO TempVentasProductos (Cod_Producto, Nombre, CantidadVendida)
    SELECT 
        P.Cod_Producto, 
        P.Nombre, 
        COALESCE(SUM(PV.Cantidad_Venta), 0) AS CantidadVendida
    FROM Producto P
    LEFT JOIN ProductVenta PV ON P.Cod_Producto = PV.Cod_Producto
    LEFT JOIN Venta V ON PV.Cod_Venta = V.Cod_Venta AND V.Estado_Venta = 'Finalizada'
    GROUP BY P.Cod_Producto, P.Nombre;

    
    CREATE TEMPORARY TABLE TempReporte (
        Cod_Producto VARCHAR(50),
        Nombre VARCHAR(100),
        CantidadVendida INT,
        Tipo VARCHAR(20)
    );

    
    CREATE TEMPORARY TABLE TempMasVendidos (
        Cod_Producto VARCHAR(50)
    );

    
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto, 
        Nombre, 
        CantidadVendida,
        'Mas Vendido' AS Tipo
    FROM TempVentasProductos
    WHERE CantidadVendida > 0
    ORDER BY CantidadVendida DESC
    LIMIT 5;

    
    INSERT INTO TempMasVendidos (Cod_Producto)
    SELECT Cod_Producto FROM TempReporte WHERE Tipo = 'Mas Vendido';

    
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto,
        Nombre,
        CantidadVendida,
        'Menos Vendido' AS Tipo
    FROM TempVentasProductos
    WHERE CantidadVendida > 0
      AND Cod_Producto NOT IN (SELECT Cod_Producto FROM TempMasVendidos)
    ORDER BY CantidadVendida ASC
    LIMIT 5;

    
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto,
        Nombre,
        0,
        'No Vendido'
    FROM TempVentasProductos
    WHERE CantidadVendida = 0;

    
    SELECT * FROM TempReporte
    ORDER BY 
        CASE Tipo
            WHEN 'Mas Vendido' THEN 1
            WHEN 'Menos Vendido' THEN 2
            WHEN 'No Vendido' THEN 3
        END,
        CASE WHEN Tipo = 'Menos Vendido' THEN CantidadVendida ELSE -CantidadVendida END;

    
    DROP TEMPORARY TABLE IF EXISTS TempMasVendidos;
    DROP TEMPORARY TABLE IF EXISTS TempVentasProductos;
    DROP TEMPORARY TABLE IF EXISTS TempReporte;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ResetPasswordToDefault` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `ResetPasswordToDefault`(IN emp_id INT)
BEGIN
    
    DECLARE default_pass VARCHAR(255);
    
    
    SET default_pass = '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrYV8LJ2JmspXb6X3JQ0QjRXU9J7WnK';
    
    
    UPDATE Empleado 
    SET Contraseña = default_pass
    WHERE Cod_Empleado = emp_id;
    
    
    SELECT ROW_COUNT() AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_bodega` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `sp_reporte_bodega`(
    IN sector_param VARCHAR(50),
    IN filtro VARCHAR(10)
)
BEGIN
    
    DECLARE fecha_filtro DATE;
    
    
    CASE filtro
        WHEN 'diario' THEN SET fecha_filtro = DATE_SUB(CURDATE(), INTERVAL 1 DAY);
        WHEN 'semanal' THEN SET fecha_filtro = DATE_SUB(CURDATE(), INTERVAL 7 DAY);
        WHEN 'mensual' THEN SET fecha_filtro = DATE_SUB(CURDATE(), INTERVAL 1 MONTH);
        ELSE SET fecha_filtro = NULL; 
    END CASE;
    
    
    SELECT 
        p.Cod_Producto,
        p.Nombre,
        p.Marca,
        pp.Fecha_Entrada AS FechaEntrada,
        pp.Cantidad,
        p.FechaVencimiento,
        p.Sector
    FROM 
        Producto p
    JOIN 
        ProveProduct pp ON p.Cod_Producto = pp.Cod_Producto
    WHERE 
        p.Sector = sector_param 
        AND p.Estado = 'Activo'
        AND (fecha_filtro IS NULL OR pp.Fecha_Entrada >= fecha_filtro);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-18 23:29:25
