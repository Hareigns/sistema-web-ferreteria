-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ferreteria
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `Cod_Empleado` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Direccion` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT NULL,
  `FechaIngreso` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Cedula` varchar(14) DEFAULT NULL,
  `Contraseña` varchar(255) DEFAULT '1234',
  PRIMARY KEY (`Cod_Empleado`),
  CONSTRAINT `CHK_Cedula_Formato` CHECK (regexp_like(`Cedula`,_utf8mb4'^[0-9]{13}[A-Z]$'))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,'Luis','Torres','Barrio San Luis','Activo','2025-05-05 21:37:54','0012304561234A','$2b$10$nrKUIwz5qNlyBGI7eI3ceeb.mWWIwyxNAaJnOrbJBYN/MBdEzDItq'),(2,'Sofia','Alvarado','Colonial Luis','Activo','2025-05-18 03:19:26','0012610001030Y','$2b$10$bNDzrRXNy/oelBCtKlkz5OcmJ381lglaunwoHYZsWpAE2ltsQnGWG'),(3,'Jorge','Mendez','Barrio San Luis','Activo','2025-05-18 03:20:12','0013001972015Q','$2b$10$Zi5pN4H7xth4RLeCA2Uxs.lDiLYjsY8gK42yVjKPwuNO.6tLqP5kC'),(4,'Maria','Juarez','Barrio San Sebastian','Activo','2025-05-19 05:26:38','1112512983033M','$2b$10$z6vxc6Aqp6edbw4o.VFia.HhE2ae0hMAt/ABTDtw/La1sGh2ICzAy'),(5,'Paulo','Rivera','Barrio San Luis','Activo','2025-05-19 05:27:57','1810906954411J','$2b$10$k69KcY5u1WcPQ5Hxwzf0be/CFEOKphckPvbxg0vpi.fIC4W8vg/Fm');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `Cod_Producto` int NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Marca` varchar(50) DEFAULT NULL,
  `FechaVencimiento` date DEFAULT NULL,
  `Sector` varchar(50) DEFAULT NULL,
  `Estado` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'Activo',
  `Descripcion` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`Cod_Producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,'Martillo de acero','Truper',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 3, Espacio 2'),(2,'Destornillador plano','Stanley',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 2, Espacio 1'),(3,'Llave inglesa 12\"','Pretul',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 4, Espacio 3'),(4,'Serrucho para madera','Irwin',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 1, Espacio 4'),(5,'Tenaza universal','Surtek',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 5, Espacio 1'),(6,'Cinta métrica 5m','Truper',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 3, Espacio 4'),(7,'Formón 1/2\"','Stanley',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 6, Espacio 2'),(8,'Nivel de mano 60cm','Kobalt',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 2, Espacio 3'),(9,'Cuchilla retráctil','Stanley',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 4, Espacio 1'),(10,'Alicate de presión','Irwin',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 5, Espacio 2'),(11,'Lima para metal','Bahco',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 1, Espacio 2'),(12,'Juego de llaves Allen','Pretul',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 6, Espacio 3'),(13,'Cizalla para metal','Truper',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 3, Espacio 1'),(14,'Extractor de clavos','Urrea',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 2, Espacio 4'),(15,'Cepillo de carpintero','Stanley',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 5, Espacio 3'),(16,'Taladro percutor 1/2\"','Bosch',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 1, Espacio 1'),(17,'Pulidora 4.5\"','Dewalt',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 3, Espacio 2'),(18,'Sierra circular 7\"','Makita',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 2, Espacio 3'),(19,'Rotomartillo','Truper',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 4, Espacio 1'),(20,'Multiherramienta oscilante','Dremel',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 5, Espacio 2'),(21,'Pistola de calor','Black+Decker',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 1, Espacio 3'),(22,'Lijadora orbital','Makita',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 6, Espacio 4'),(23,'Fresadora de mano','Bosch',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 3, Espacio 1'),(24,'Atornillador inalámbrico','Stanley',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 4, Espacio 2'),(25,'Sierra caladora','Einhell',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 2, Espacio 4'),(26,'Compresor de aire','Hyundai',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 5, Espacio 3'),(27,'Lámpara portátil LED','Makita',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 6, Espacio 1'),(28,'Cortador de azulejos eléctrico','Truper',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 1, Espacio 2'),(29,'Cargador de baterías','Black+Decker',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 3, Espacio 3'),(30,'Engrapadora eléctrica','Stanley',NULL,'Herramientas eléctricas','Activo','Estante 2, Repisa 4, Espacio 4'),(31,'Cemento Portland 50kg','Cemex','2026-03-01','Materiales de construcción','Activo','Estante 3, Repisa 6, Espacio 1'),(32,'Arena fina metro cúbico','Construmix',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 5, Espacio 2'),(33,'Ladrillo rojo artesanal','LadriNica',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 4, Espacio 3'),(34,'Bloque concreto 15x20x40','Construblock',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 3, Espacio 4'),(35,'Hierro corrugado 3/8\"','MetalNica',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 2, Espacio 1'),(36,'Malla electrosoldada','Construred',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 1, Espacio 2'),(37,'Piedrín metro cúbico','AgregadosNica',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 6, Espacio 3'),(38,'Pegamento para cerámica','Lanco','2025-12-10','Materiales de construcción','Activo','Estante 3, Repisa 5, Espacio 4'),(39,'Cal hidratada','CalNica',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 4, Espacio 1'),(40,'Plancha de zinc','Zincalum',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 3, Espacio 2'),(41,'Canaleta galvanizada','MetalNica',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 2, Espacio 3'),(42,'Pintura impermeabilizante','Lanco','2025-11-05','Materiales de construcción','Activo','Estante 3, Repisa 1, Espacio 4'),(43,'Clavo de concreto 2\"','Pretul',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 6, Espacio 2'),(44,'Yeso en saco 25kg','Suvinil',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 5, Espacio 1'),(45,'Adhesivo para drywall','Truper',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 4, Espacio 2'),(46,'Lija de agua 400','Norton',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 1, Espacio 3'),(47,'Bandeja para pintura','Pretul',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 2, Espacio 4'),(48,'Pintura en aerosol negra','Krylon','2025-05-18','Pinturas o accesorios','Activo','Estante 4, Repisa 3, Espacio 1'),(49,'Sellador para madera','Comex',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 4, Espacio 2'),(50,'Disolvente industrial','ThinnerX','2026-08-15','Pinturas o accesorios','Activo','Estante 4, Repisa 5, Espacio 3'),(51,'Espátula metálica','Truper',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 6, Espacio 4'),(52,'Pintura epóxica gris','Lanco','2027-01-10','Pinturas o accesorios','Activo','Estante 4, Repisa 1, Espacio 1'),(53,'Rodillo anti goteo','Truper',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 2, Espacio 2'),(54,'Tinte color nogal','Comex','2026-11-01','Pinturas o accesorios','Activo','Estante 4, Repisa 3, Espacio 3'),(55,'Diluyente sintético','Pintulac','2026-09-30','Pinturas o accesorios','Activo','Estante 4, Repisa 4, Espacio 4'),(56,'Pintura acrílica blanca','Lanco','2025-05-25','Pinturas o accesorios','Activo','Estante 4, Repisa 5, Espacio 1'),(57,'Rodillo de lana','Truper',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 6, Espacio 2'),(58,'Brocha de 2 pulgadas','Sur',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 1, Espacio 3'),(59,'Remoedor de pintura','Lanco','2026-12-01','Pinturas o accesorios','Activo','Estante 4, Repisa 2, Espacio 4'),(60,'Cinta para enmascarar','3M',NULL,'Pinturas o accesorios','Activo','Estante 4, Repisa 3, Espacio 1'),(61,'Tubo PVC ½ pulgada','Amanco',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 4, Espacio 2'),(62,'Codo PVC 90°','Amanco',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 3, Espacio 3'),(63,'Tee PVC sanitaria','Amanco',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 2, Espacio 4'),(64,'Válvula esfera ½ pulgada','Hydroflow',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 1, Espacio 1'),(65,'Llave de paso ¾ pulgada','Genebre',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 6, Espacio 2'),(66,'Adaptador macho PVC','Amanco',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 5, Espacio 3'),(67,'Pegamento para PVC','Tigre','2026-09-01','Tuberías y plomería','Activo','Estante 5, Repisa 4, Espacio 4'),(68,'Manguera de jardín 10m','Pretul',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 3, Espacio 1'),(69,'Ducha de mano','Fybeca',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 2, Espacio 2'),(70,'Lavamanos cerámico','Corona',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 1, Espacio 3'),(71,'Grifo monomando','Hydrolite',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 6, Espacio 4'),(72,'Sifón flexible PVC','Siflex',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 5, Espacio 1'),(73,'Tanque para sanitario','Corona',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 4, Espacio 2'),(74,'Tubo PEX 3/8 pulgada','Rehau',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 3, Espacio 3'),(75,'Llave lavamanos sencilla','Truper',NULL,'Tuberías y plomería','Activo','Estante 5, Repisa 2, Espacio 4'),(76,'Interruptor sencillo','Bticino',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 1, Espacio 1'),(77,'Tomacorriente doble','Bticino',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 2, Espacio 2'),(78,'Caja para toma','Genérico',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 3, Espacio 3'),(79,'Tubo conduit PVC ½ pulgada','Condutelec',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 4, Espacio 4'),(80,'Cable THW 12 AWG','Centelsa',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 5, Espacio 1'),(81,'Cable THW 14 AWG','Viakon',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 6, Espacio 2'),(82,'Regleta de 6 tomas','Koblenz',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 1, Espacio 3'),(83,'Foco LED 9W','Philips',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 2, Espacio 4'),(84,'Foco ahorrador 14W','Sylvania',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 3, Espacio 1'),(85,'Lámpara de techo','Luxtek',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 4, Espacio 2'),(86,'Sensor de movimiento','Energizer',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 5, Espacio 3'),(87,'Fotocelda','Veto',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 6, Espacio 4'),(88,'Timbre inalámbrico','Honeywell',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 1, Espacio 1'),(89,'Caja de distribución','Square D',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 2, Espacio 2'),(90,'Breakers 20A','Schneider',NULL,'Electricidad e iluminación','Activo','Estante 6, Repisa 3, Espacio 3'),(91,'Casco de seguridad','3M',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 4, Espacio 4'),(92,'Guantes de cuero','Delta Plus',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 5, Espacio 1'),(93,'Lentes de protección','Honeywell',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 6, Espacio 2'),(94,'Botas dieléctricas','Industrial Safety',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 1, Espacio 3'),(95,'Chaleco reflectivo','Segurimax',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 2, Espacio 4'),(96,'Protector auditivo tipo copa','3M',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 3, Espacio 1'),(97,'Respirador con filtros','3M',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 4, Espacio 2'),(98,'Arnés de seguridad','MSA',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 5, Espacio 3'),(99,'Rodilleras','Protec',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 6, Espacio 4'),(100,'Faja lumbar','Seguridad Total',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 1, Espacio 1'),(101,'Extintor multipropósito 10 lbs','Kidde','2029-01-01','Seguridad industrial','Activo','Estante 7, Repisa 2, Espacio 2'),(102,'Máscara de soldadura','Lincoln Electric',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 3, Espacio 3'),(103,'Impermeable industrial','Stormline',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 4, Espacio 4'),(104,'Detector de gas portátil','BW Technologies',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 5, Espacio 1'),(105,'Botiquín de primeros auxilios','Genérico',NULL,'Seguridad industrial','Activo','Estante 7, Repisa 6, Espacio 2'),(106,'Candado de acero 50mm','Yale',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 1, Espacio 3'),(107,'Flexómetro 5m','Truper',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 2, Espacio 4'),(108,'Cinta aislante','3M',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 3, Espacio 1'),(109,'Teflón para roscas','Genérico',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 4, Espacio 2'),(110,'Llave ajustable 10\"','Pretul',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 5, Espacio 3'),(111,'Nivel de mano 30cm','Stanley',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 6, Espacio 4'),(112,'Destornillador plano 6\"','Truper',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 1, Espacio 1'),(113,'Destornillador Phillips 6\"','Truper',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 2, Espacio 2'),(114,'Caja de herramientas plástica','Toolcraft',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 3, Espacio 3'),(115,'Silicón sellador transparente','Fester',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 4, Espacio 4'),(116,'Tornillos para concreto 2\"','Fiero',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 5, Espacio 1'),(117,'Pega instantánea','UHU',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 6, Espacio 2'),(118,'Llave hexagonal juego 10 pzas','Stanley',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 1, Espacio 3'),(119,'Pulidora angular 4.5\"','DeWalt',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 2, Espacio 4'),(120,'Brochas para pintar 3\"','Pintuco',NULL,'Productos de ferretería general','Activo','Estante 8, Repisa 3, Espacio 1'),(121,'prueba','Trupper',NULL,'Herramientas manuales','Activo','Estante 3, Repisa 4, Espacio 3'),(122,'prueba','Trupper',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 3, Espacio 3'),(123,'prueba','Bosch',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 6, Espacio 2'),(124,'prueba','Trupper',NULL,'Herramientas manuales','Activo','Estante 1, Repisa 4, Espacio 4'),(125,'prueba','Bosch',NULL,'Herramientas eléctricas','Activo','Estante 5, Repisa 1, Espacio 4'),(126,'prueba','Latex',NULL,'Materiales de construcción','Activo','Estante 3, Repisa 1, Espacio 4');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productventa`
--

DROP TABLE IF EXISTS `productventa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productventa` (
  `Cod_Producto` int NOT NULL,
  `Cod_Venta` int NOT NULL,
  `Metodo_Pago` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Precio_Venta` float DEFAULT NULL,
  `Cantidad_Venta` float DEFAULT NULL,
  `Sector` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Fecha_salida` date DEFAULT NULL,
  PRIMARY KEY (`Cod_Venta`,`Cod_Producto`),
  KEY `Cod_Producto` (`Cod_Producto`),
  CONSTRAINT `productventa_ibfk_1` FOREIGN KEY (`Cod_Producto`) REFERENCES `producto` (`Cod_Producto`),
  CONSTRAINT `productventa_ibfk_2` FOREIGN KEY (`Cod_Venta`) REFERENCES `venta` (`Cod_Venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productventa`
--

LOCK TABLES `productventa` WRITE;
/*!40000 ALTER TABLE `productventa` DISABLE KEYS */;
INSERT INTO `productventa` VALUES (20,1,'Efectivo',520.66,8,'Herramientas eléctricas','2025-05-17'),(103,2,'Efectivo',139.17,1,'Seguridad industrial','2025-05-17'),(12,3,'Transferencia',303.01,4,'Herramientas manuales','2025-05-17'),(76,4,'Efectivo',74.17,9,'Electricidad e iluminación','2025-05-17'),(52,5,'Tarjeta',77.59,4,'Pinturas o accesorios','2025-05-17'),(51,6,'Efectivo',693.01,8,'Pinturas o accesorios','2025-05-17'),(87,7,'Transferencia',348.82,10,'Electricidad e iluminación','2025-05-17'),(65,8,'Transferencia',914.48,2,'Tuberías y plomería','2025-05-17'),(6,9,'Transferencia',530.1,5,'Herramientas manuales','2025-05-17'),(44,10,'Tarjeta',129.72,6,'Materiales de construcción','2025-05-17'),(24,11,'Efectivo',559.37,2,'Herramientas eléctricas','2025-05-18'),(18,12,'Tarjeta',402.31,10,'Herramientas eléctricas','2025-05-18'),(31,13,'Transferencia',462.29,6,'Materiales de construcción','2025-05-18'),(68,14,'Tarjeta',641.96,10,'Tuberías y plomería','2025-05-18'),(88,15,'Efectivo',311.44,1,'Electricidad e iluminación','2025-05-18'),(78,16,'Transferencia',421.36,7,'Electricidad e iluminación','2025-05-18'),(17,17,'Transferencia',550.23,5,'Herramientas eléctricas','2025-05-18'),(50,18,'Transferencia',361.5,4,'Pinturas o accesorios','2025-05-18'),(39,19,'Efectivo',120.57,10,'Materiales de construcción','2025-05-18'),(2,20,'Transferencia',775.6,6,'Herramientas manuales','2025-05-18'),(105,21,'Tarjeta',438.34,2,'Seguridad industrial','2025-05-19'),(43,22,'Transferencia',229.76,3,'Materiales de construcción','2025-05-19'),(111,23,'Transferencia',271.66,10,'Productos de ferretería general','2025-05-19'),(7,24,'Efectivo',891.23,3,'Herramientas manuales','2025-05-19'),(96,25,'Tarjeta',387.74,1,'Seguridad industrial','2025-05-19'),(109,26,'Efectivo',598.66,3,'Productos de ferretería general','2025-05-19'),(120,27,'Transferencia',618.99,2,'Productos de ferretería general','2025-05-19'),(85,28,'Transferencia',299.01,9,'Electricidad e iluminación','2025-05-19'),(113,29,'Tarjeta',198.4,8,'Productos de ferretería general','2025-05-19'),(91,30,'Tarjeta',333.68,4,'Seguridad industrial','2025-05-19'),(3,31,'Efectivo',300,3,'Herramientas manuales','2025-05-20'),(112,31,'Transferencia',540.75,3,'Productos de ferretería general','2025-05-21'),(31,32,'Tarjeta',268.75,3,'Materiales de construcción','2025-05-20'),(33,32,'Tarjeta',8.13,3,'Materiales de construcción','2025-05-20'),(34,32,'Tarjeta',15.63,5,'Materiales de construcción','2025-05-20'),(66,32,'Efectivo',305.4,5,'Tuberías y plomería','2025-05-21'),(23,33,'Tarjeta',712.9,2,'Herramientas eléctricas','2025-05-21'),(91,33,'Efectivo',225,5,'Seguridad industrial','2025-05-20'),(47,34,'Efectivo',158.3,6,'Materiales de construcción','2025-05-21'),(106,34,'Transferencia',187.5,5,'Productos de ferretería general','2025-05-20'),(102,35,'Transferencia',620.5,1,'Seguridad industrial','2025-05-21'),(79,36,'Tarjeta',400.1,4,'Electricidad e iluminación','2025-05-21'),(53,37,'Efectivo',99.99,7,'Pinturas o accesorios','2025-05-21'),(5,38,'Transferencia',850,3,'Herramientas manuales','2025-05-21'),(110,39,'Tarjeta',275.6,2,'Productos de ferretería general','2025-05-21'),(114,40,'Efectivo',333.33,5,'Productos de ferretería general','2025-05-21'),(2,45,'Efectivo',93.75,5,'Herramientas manuales','2025-05-22'),(8,45,'Efectivo',137.5,5,'Herramientas manuales','2025-05-22'),(11,45,'Efectivo',112.5,10,'Herramientas manuales','2025-05-22'),(54,46,'Efectivo',93.75,10,'Pinturas o accesorios','2025-05-22'),(76,46,'Efectivo',31.25,5,'Electricidad e iluminación','2025-05-22'),(86,46,'Transferencia',350,6,'Electricidad e iluminación','2025-05-22'),(106,47,'Efectivo',187.5,10,'Productos de ferretería general','2025-05-22');
/*!40000 ALTER TABLE `productventa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedor` (
  `Cod_Proveedor` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Sector` varchar(50) DEFAULT NULL,
  `Estado` enum('Activo','Inactivo') DEFAULT NULL,
  PRIMARY KEY (`Cod_Proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (1,'Jorge','Mendez','Herramientas manuales','Activo'),(2,'Carla','Ruiz','Herramientas manuales','Activo'),(3,'Mario','Torres','Herramientas eléctricas','Activo'),(4,'Elena','Cordero','Herramientas eléctricas','Activo'),(5,'Luis','Gonzales','Materiales de construcción','Activo'),(6,'Mariela','Perez','Materiales de construcción','Activo'),(7,'Ana','Morales','Pinturas o accesorios','Activo'),(8,'Diego','Castillo','Pinturas o accesorios','Activo'),(9,'Roberto','Salgado','Tuberías y plomería','Activo'),(10,'Gabriela','Molina','Tuberías y plomería','Activo'),(11,'Carlos','Navarro','Electricidad e iluminación','Activo'),(12,'Ingrid','Lopez','Electricidad e iluminación','Activo'),(13,'Fernando','Reyes','Seguridad industrial','Activo'),(14,'Patricia','Duarte','Seguridad industrial','Activo'),(15,'Esteban','Rivas','Productos de ferretería general','Activo'),(16,'Julia','Campos','Productos de ferretería general','Activo');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveproduct`
--

DROP TABLE IF EXISTS `proveproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveproduct` (
  `Cod_Proveedor` int NOT NULL,
  `Cod_Producto` int NOT NULL,
  `Fecha_Entrada` date DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  `Cantidad` int DEFAULT NULL,
  PRIMARY KEY (`Cod_Proveedor`,`Cod_Producto`),
  KEY `Cod_Producto` (`Cod_Producto`),
  CONSTRAINT `proveproduct_ibfk_1` FOREIGN KEY (`Cod_Proveedor`) REFERENCES `proveedor` (`Cod_Proveedor`),
  CONSTRAINT `proveproduct_ibfk_2` FOREIGN KEY (`Cod_Producto`) REFERENCES `producto` (`Cod_Producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveproduct`
--

LOCK TABLES `proveproduct` WRITE;
/*!40000 ALTER TABLE `proveproduct` DISABLE KEYS */;
INSERT INTO `proveproduct` VALUES (1,1,'2025-05-11',200,44),(1,2,'2025-05-11',75,60),(1,3,'2025-05-11',240,27),(1,7,'2025-05-11',80,40),(1,8,'2025-05-11',110,20),(1,11,'2025-05-11',90,25),(1,14,'2025-05-11',140,28),(1,15,'2025-05-11',170,32),(1,121,'2025-06-04',23,34),(1,123,'2025-06-04',24,45),(2,4,'2025-05-11',125,20),(2,5,'2025-05-11',85,50),(2,6,'2025-05-11',55,70),(2,9,'2025-05-11',95,1),(2,10,'2025-05-11',150,60),(2,12,'2025-05-11',105,45),(2,13,'2025-05-11',220,15),(2,122,'2025-06-05',23,34),(2,124,'2025-06-04',24,45),(3,16,'2025-05-12',1350,10),(3,17,'2025-05-12',1450,12),(3,18,'2025-05-12',2200,8),(3,22,'2025-05-12',980,6),(3,23,'2025-05-12',1100,10),(3,26,'2025-05-12',2550,5),(3,29,'2025-05-12',820,15),(3,30,'2025-05-12',920,14),(3,125,'2025-06-04',23,45),(4,19,'2025-05-12',1600,9),(4,20,'2025-05-12',1150,7),(4,21,'2025-05-12',850,15),(4,24,'2025-05-12',740,20),(4,25,'2025-05-12',990,11),(4,27,'2025-05-12',450,25),(4,28,'2025-05-12',1050,6),(5,31,'2025-05-13',215,37),(5,32,'2025-05-13',130,35),(5,33,'2025-05-13',6.5,297),(5,36,'2025-05-13',220,45),(5,37,'2025-05-13',140,38),(5,43,'2025-05-13',0.9,500),(5,44,'2025-05-13',85,40),(5,45,'2025-05-13',75,45),(5,126,'2025-06-04',24,45),(6,34,'2025-05-13',12.5,245),(6,35,'2025-05-13',175,100),(6,38,'2025-05-13',95,50),(6,39,'2025-05-13',30,100),(6,40,'2025-05-13',115,60),(6,41,'2025-05-13',95,65),(6,42,'2025-05-13',150,50),(7,51,'2025-05-14',70,55),(7,52,'2025-05-14',250,25),(7,53,'2025-05-14',95,45),(7,54,'2025-05-14',75,23),(7,55,'2025-05-14',140,30),(7,56,'2025-05-14',220,35),(7,57,'2025-05-14',90,50),(7,58,'2025-05-14',45,60),(7,59,'2025-05-14',150,30),(8,46,'2025-05-14',10,200),(8,47,'2025-05-14',55,70),(8,48,'2025-05-14',120,40),(8,49,'2025-05-14',110,35),(8,50,'2025-05-14',160,20),(8,60,'2025-05-14',30,100),(9,61,'2025-05-15',35,200),(9,62,'2025-05-15',20,250),(9,63,'2025-05-15',28,180),(9,70,'2025-05-15',450,15),(9,71,'2025-05-15',190,28),(9,72,'2025-05-15',75,50),(9,73,'2025-05-15',380,12),(9,74,'2025-05-15',60,110),(9,75,'2025-05-15',95,60),(10,64,'2025-05-15',65,90),(10,65,'2025-05-15',70,85),(10,66,'2025-05-15',18,300),(10,67,'2025-05-15',95,40),(10,68,'2025-05-15',140,35),(10,69,'2025-05-15',160,30),(11,76,'2025-05-16',25,395),(11,77,'2025-05-16',30,300),(11,78,'2025-05-16',15,350),(11,79,'2025-05-16',22,240),(11,80,'2025-05-16',450,90),(11,88,'2025-05-16',190,50),(11,89,'2025-05-16',390,20),(11,90,'2025-05-16',140,70),(12,81,'2025-05-16',380,95),(12,82,'2025-05-16',210,80),(12,83,'2025-05-16',50,300),(12,84,'2025-05-16',45,250),(12,85,'2025-05-16',600,25),(12,86,'2025-05-16',280,34),(12,87,'2025-05-16',110,75),(13,91,'2025-05-17',180,75),(13,92,'2025-05-17',90,150),(13,93,'2025-05-17',70,140),(13,94,'2025-05-17',620,30),(13,103,'2025-05-17',310,35),(13,104,'2025-05-17',1800,5),(13,105,'2025-05-17',160,40),(14,95,'2025-05-17',55,120),(14,96,'2025-05-17',140,50),(14,97,'2025-05-17',320,40),(14,98,'2025-05-17',750,15),(14,99,'2025-05-17',85,90),(14,100,'2025-05-17',130,60),(14,101,'2025-05-17',780,10),(14,102,'2025-05-17',450,25),(15,106,'2025-05-18',150,35),(15,107,'2025-05-18',95,70),(15,108,'2025-05-18',20,300),(15,109,'2025-05-18',25,180),(15,110,'2025-05-18',120,40),(16,111,'2025-05-18',85,60),(16,112,'2025-05-18',45,110),(16,113,'2025-05-18',45,100),(16,114,'2025-05-18',280,25),(16,115,'2025-05-18',60,90),(16,116,'2025-05-18',40,200),(16,117,'2025-05-18',35,150),(16,118,'2025-05-18',140,30),(16,119,'2025-05-18',1250,12),(16,120,'2025-05-18',30,120);
/*!40000 ALTER TABLE `proveproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('am7IbltjcHyetLQwajs_suXTLDCqbxlG',1749177161,'{\"cookie\":{\"originalMaxAge\":86400000,\"expires\":\"2025-06-06T02:32:41.263Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"flash\":{\"error\":[\"Por favor inicie sesión\"]}}'),('iCJYCF7R5g16OxCrgfyZHmFl5T_7RIOi',1749182019,'{\"cookie\":{\"originalMaxAge\":86400000,\"expires\":\"2025-06-06T03:44:57.644Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/\",\"sameSite\":\"lax\"},\"passport\":{\"user\":1},\"flash\":{}}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telefono`
--

DROP TABLE IF EXISTS `telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telefono` (
  `Numero` varchar(9) NOT NULL,
  `Compania` varchar(50) NOT NULL,
  `Cod_Proveedor` int DEFAULT NULL,
  `Cod_Empleado` int DEFAULT NULL,
  PRIMARY KEY (`Numero`),
  KEY `Cod_Proveedor` (`Cod_Proveedor`),
  KEY `Cod_Empleado` (`Cod_Empleado`),
  CONSTRAINT `telefono_ibfk_1` FOREIGN KEY (`Cod_Proveedor`) REFERENCES `proveedor` (`Cod_Proveedor`),
  CONSTRAINT `telefono_ibfk_2` FOREIGN KEY (`Cod_Empleado`) REFERENCES `empleado` (`Cod_Empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telefono`
--

LOCK TABLES `telefono` WRITE;
/*!40000 ALTER TABLE `telefono` DISABLE KEYS */;
INSERT INTO `telefono` VALUES ('123456780','Tigo',NULL,1),('65253412','Claro',NULL,4),('77955356','Tigo',NULL,3),('78789898','Claro',NULL,5),('81825567','Claro',15,NULL),('81902288','Claro',10,NULL),('83214455','Claro',13,NULL),('83456678','Claro',4,NULL),('84125513','Tigo',7,NULL),('84321023','Claro',14,NULL),('84832210','Tigo',1,NULL),('85207784','Tigo',8,NULL),('85679012','Tigo',2,NULL),('85843310','Claro',16,NULL),('85904321','Claro',5,NULL),('86439087','Claro',12,NULL),('87031199','Claro',6,NULL),('87535453','Tigo',NULL,2),('87556666','Claro',11,NULL),('87891200','Claro',3,NULL),('88763211','Claro',9,NULL);
/*!40000 ALTER TABLE `telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `Cod_Venta` int NOT NULL AUTO_INCREMENT,
  `Estado_Venta` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Cod_Empleado` int DEFAULT NULL,
  PRIMARY KEY (`Cod_Venta`),
  KEY `Cod_Empleado` (`Cod_Empleado`),
  CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`Cod_Empleado`) REFERENCES `empleado` (`Cod_Empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (1,'Completada',2),(2,'Completada',4),(3,'Completada',4),(4,'Completada',5),(5,'Completada',1),(6,'Completada',4),(7,'Completada',3),(8,'Completada',2),(9,'Completada',4),(10,'Completada',5),(11,'Completada',4),(12,'Completada',1),(13,'Completada',3),(14,'Completada',5),(15,'Completada',1),(16,'Completada',3),(17,'Completada',4),(18,'Completada',4),(19,'Completada',2),(20,'Completada',1),(21,'Completada',2),(22,'Completada',4),(23,'Completada',3),(24,'Completada',3),(25,'Completada',4),(26,'Completada',4),(27,'Completada',5),(28,'Completada',2),(29,'Completada',5),(30,'Completada',5),(31,'Completada',1),(32,'Completada',1),(33,'Completada',1),(34,'Completada',1),(35,'Completada',1),(36,'Completada',2),(37,'Completada',3),(38,'Completada',4),(39,'Completada',5),(40,'Completada',1),(41,'Completada',2),(42,'Completada',3),(43,'Completada',4),(44,'Completada',5),(45,'Completada',1),(46,'Completada',1),(47,'Completada',1);
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ferreteria'
--

--
-- Dumping routines for database 'ferreteria'
--
/*!50003 DROP PROCEDURE IF EXISTS `ReporteProductosVendidos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `ReporteProductosVendidos`()
BEGIN
    -- Eliminar tablas temporales si existen
    DROP TEMPORARY TABLE IF EXISTS TempReporte;
    DROP TEMPORARY TABLE IF EXISTS TempVentasProductos;
    DROP TEMPORARY TABLE IF EXISTS TempMasVendidos;

    -- Crear tabla temporal para todos los productos vendidos con sus cantidades
    CREATE TEMPORARY TABLE TempVentasProductos (
        Cod_Producto VARCHAR(50),
        Nombre VARCHAR(100),
        CantidadVendida INT
    );

    -- Insertar todos los productos vendidos con sus cantidades
    INSERT INTO TempVentasProductos (Cod_Producto, Nombre, CantidadVendida)
    SELECT 
        P.Cod_Producto, 
        P.Nombre, 
        COALESCE(SUM(PV.Cantidad_Venta), 0) AS CantidadVendida
    FROM 
        Producto P
    LEFT JOIN 
        ProductVenta PV ON P.Cod_Producto = PV.Cod_Producto
    LEFT JOIN 
        Venta V ON PV.Cod_Venta = V.Cod_Venta AND V.Estado_Venta = 'Finalizada'
    GROUP BY 
        P.Cod_Producto, P.Nombre;

    -- Crear tabla para el reporte final
    CREATE TEMPORARY TABLE TempReporte (
        Cod_Producto VARCHAR(50),
        Nombre VARCHAR(100),
        CantidadVendida INT,
        Tipo VARCHAR(20)
    );

    -- Tabla temporal para los más vendidos
    CREATE TEMPORARY TABLE TempMasVendidos (
        Cod_Producto VARCHAR(50)
    );

    -- Insertar productos más vendidos (Top 5 con cantidad de ventas más alta)
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto, 
        Nombre, 
        CantidadVendida,
        'Más Vendido' AS Tipo
    FROM 
        TempVentasProductos
    WHERE 
        CantidadVendida > 0
    ORDER BY 
        CantidadVendida DESC
    LIMIT 5;

    -- Guardar los códigos de los más vendidos
    INSERT INTO TempMasVendidos (Cod_Producto)
    SELECT Cod_Producto FROM TempReporte WHERE Tipo = 'Más Vendido';

    -- Insertar productos menos vendidos (excluyendo los más vendidos)
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto,
        Nombre,
        CantidadVendida,
        'Menos Vendido' AS Tipo
    FROM 
        TempVentasProductos
    WHERE 
        CantidadVendida > 0
        AND Cod_Producto NOT IN (SELECT Cod_Producto FROM TempMasVendidos)
    ORDER BY 
        CantidadVendida ASC
    LIMIT 5;

    -- Insertar productos no vendidos
    INSERT INTO TempReporte (Cod_Producto, Nombre, CantidadVendida, Tipo)
    SELECT 
        Cod_Producto,
        Nombre,
        0,
        'No Vendido'
    FROM 
        TempVentasProductos
    WHERE 
        CantidadVendida = 0;

    -- Mostrar resultado consolidado ordenado por tipo y cantidad
    SELECT 
        Cod_Producto,
        Nombre,
        CantidadVendida,
        Tipo
    FROM 
        TempReporte
    ORDER BY 
        CASE Tipo
            WHEN 'Más Vendido' THEN 1
            WHEN 'Menos Vendido' THEN 2
            WHEN 'No Vendido' THEN 3
        END,
        CASE 
            WHEN Tipo = 'Menos Vendido' THEN CantidadVendida 
            ELSE -CantidadVendida 
        END;

    -- Limpieza (las tablas temporales se eliminarán automáticamente al final de la sesión)
    DROP TEMPORARY TABLE IF EXISTS TempMasVendidos;
    DROP TEMPORARY TABLE IF EXISTS TempVentasProductos;
    DROP TEMPORARY TABLE IF EXISTS TempReporte;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ResetPasswordToDefault` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `ResetPasswordToDefault`(IN emp_id INT)
BEGIN
    -- Declarar variable para la contraseña temporal
    DECLARE default_pass VARCHAR(255);
    
    -- Este es un hash de ejemplo para '1234'
    SET default_pass = '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrYV8LJ2JmspXb6X3JQ0QjRXU9J7WnK';
    
    -- Actualizar la contraseña
    UPDATE Empleado 
    SET Contraseña = default_pass
    WHERE Cod_Empleado = emp_id;
    
    -- Devolver el número de filas afectadas
    SELECT ROW_COUNT() AS affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_bodega` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `sp_reporte_bodega`(
    IN sector_param VARCHAR(50),
    IN periodo_param VARCHAR(10),
    IN search_term VARCHAR(100)
)
BEGIN
    -- Variables para condiciones dinámicas
    DECLARE sector_condition VARCHAR(200) DEFAULT '';
    DECLARE periodo_condition VARCHAR(200) DEFAULT '';
    DECLARE search_condition VARCHAR(200) DEFAULT '';
    
    -- Construir condición para sector (solo si se proporciona)
    IF sector_param IS NOT NULL AND sector_param != '' THEN
        SET sector_condition = CONCAT(' AND p.Sector = "', sector_param, '"');
    END IF;
    
    -- Construir condición para período (incluso si es 'todos')
    IF periodo_param IS NOT NULL THEN
        CASE periodo_param
            WHEN 'diario' THEN SET periodo_condition = ' AND pp.Fecha_Entrada >= DATE_SUB(CURDATE(), INTERVAL 1 DAY)';
            WHEN 'semanal' THEN SET periodo_condition = ' AND pp.Fecha_Entrada >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)';
            WHEN 'mensual' THEN SET periodo_condition = ' AND pp.Fecha_Entrada >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)';
            WHEN 'todos' THEN SET periodo_condition = ''; -- No filtrar por fecha
        END CASE;
    END IF;
    
    -- Construir condición para término de búsqueda
    IF search_term IS NOT NULL AND search_term != '' THEN
        SET search_condition = CONCAT(' AND (p.Nombre LIKE "%', search_term, '%" OR p.Cod_Producto LIKE "%', search_term, '%")');
    END IF;
    
     -- Consulta principal con condiciones dinámicas
    SET @sql = CONCAT('
        SELECT 
            p.Cod_Producto,
            p.Nombre,
            p.Marca,
            pp.Fecha_Entrada AS FechaEntrada,
            pp.Cantidad,
            p.FechaVencimiento,
            p.Sector,
            p.Descripcion  -- Añadir este campo
        FROM 
            Producto p
        JOIN 
            ProveProduct pp ON p.Cod_Producto = pp.Cod_Producto
        WHERE 
            p.Estado = "Activo"',
            sector_condition,
            periodo_condition,
            search_condition,
        ' ORDER BY pp.Fecha_Entrada DESC');
    
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_reporte_ventas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `sp_reporte_ventas`(
    IN filtro VARCHAR(10)
)
BEGIN
    -- Declarar variables para fechas ajustadas
    DECLARE fecha_actual DATE;
    DECLARE fecha_inicio DATE;
    DECLARE fecha_fin DATE;

    -- Validar el parámetro filtro
    IF filtro NOT IN ('diario', 'semanal', 'mensual') THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Filtro no válido. Use: diario, semanal o mensual';
    END IF;

    -- Obtener fecha actual (asegurando que sea la fecha correcta)
    SET fecha_actual = CURRENT_DATE(); -- Más explícito que CURDATE()
    SET fecha_fin = DATE_ADD(fecha_actual, INTERVAL 1 DAY); -- Para incluir todo el día actual

    -- Calcular fecha de inicio según filtro
    IF filtro = 'diario' THEN
        SET fecha_inicio = fecha_actual;  -- Solo hoy
    ELSEIF filtro = 'semanal' THEN
        SET fecha_inicio = DATE_SUB(fecha_actual, INTERVAL 6 DAY); -- últimos 7 días incluyendo hoy
    ELSE
        SET fecha_inicio = DATE_SUB(fecha_actual, INTERVAL 1 MONTH);
    END IF;

    -- Para depuración: ver las fechas que se están usando
    -- SELECT fecha_inicio AS 'Fecha Inicio', fecha_fin AS 'Fecha Fin', fecha_actual AS 'Fecha Actual';

    -- Consulta principal con filtro de fechas mejorado
    SELECT 
        v.Cod_Venta,
        pv.Cod_Producto,
        p.Nombre AS Nombre_Producto,
        pv.Cantidad_Venta,
        ROUND(SUM(pv.Precio_Venta * pv.Cantidad_Venta), 2) AS Monto_Total,
        DATE_FORMAT(pv.Fecha_salida, '%Y-%m-%d') AS Fecha_Venta
    FROM 
        Venta v
    JOIN 
        ProductVenta pv ON v.Cod_Venta = pv.Cod_Venta
    JOIN 
        Producto p ON p.Cod_Producto = pv.Cod_Producto
    WHERE
        pv.Fecha_salida >= fecha_inicio
        AND pv.Fecha_salida < fecha_fin  -- Limitar hasta el final del día actual
    GROUP BY 
        v.Cod_Venta, pv.Cod_Producto, p.Nombre, pv.Cantidad_Venta, pv.Fecha_salida;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TopProductosPorSectorConPrecio` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`user`@`%` PROCEDURE `TopProductosPorSectorConPrecio`()
BEGIN
    -- Eliminar tabla temporal si existe
    DROP TEMPORARY TABLE IF EXISTS TempTopSector;
    
    -- Crear tabla temporal para el top de productos por sector
    CREATE TEMPORARY TABLE TempTopSector (
        Sector VARCHAR(50),
        Posicion INT,
        Cod_Producto INT,
        Nombre_Producto VARCHAR(50),
        CantidadVendida FLOAT,
        PrecioVentaPromedio DECIMAL(10,2),
        TotalVendido DECIMAL(10,2),
        Icono VARCHAR(50)
    );
    
    -- Insertar los 3 productos más vendidos por cada sector con información de precios
    INSERT INTO TempTopSector
    WITH VentasPorProducto AS (
        SELECT 
            P.Sector,
            P.Cod_Producto,
            P.Nombre AS Nombre_Producto,
            COALESCE(SUM(PV.Cantidad_Venta), 0) AS CantidadVendida,
            COALESCE(AVG(PV.Precio_Venta), 0) AS PrecioVentaPromedio,
            COALESCE(SUM(PV.Cantidad_Venta * PV.Precio_Venta), 0) AS TotalVendido,
            CASE 
                WHEN P.Sector = 'Herramientas manuales' THEN 'fa-tools'
                WHEN P.Sector = 'Herramientas eléctricas' THEN 'fa-bolt'
                WHEN P.Sector = 'Materiales de construcción' THEN 'fa-cubes'
                WHEN P.Sector = 'Pinturas o accesorios' THEN 'fa-paint-roller'
                WHEN P.Sector = 'Tuberías y plomería' THEN 'fa-faucet'
                WHEN P.Sector = 'Electricidad e iluminación' THEN 'fa-lightbulb'
                WHEN P.Sector = 'Seguridad industrial' THEN 'fa-hard-hat'
                WHEN P.Sector = 'Productos de ferretería general' THEN 'fa-warehouse'
                ELSE 'fa-box'
            END AS Icono,
            ROW_NUMBER() OVER (PARTITION BY P.Sector ORDER BY COALESCE(SUM(PV.Cantidad_Venta), 0) DESC) AS Ranking
        FROM Producto P
        LEFT JOIN ProductVenta PV ON P.Cod_Producto = PV.Cod_Producto
        LEFT JOIN Venta V ON PV.Cod_Venta = V.Cod_Venta AND V.Estado_Venta = 'Finalizada'
        GROUP BY P.Sector, P.Cod_Producto, P.Nombre
        HAVING CantidadVendida > 0
    )
    SELECT 
        Sector,
        Ranking AS Posicion,
        Cod_Producto,
        Nombre_Producto,
        CantidadVendida,
        PrecioVentaPromedio,
        TotalVendido,
        Icono
    FROM VentasPorProducto
    WHERE Ranking <= 3;
    
    -- Mostrar resultados ordenados por sector y posición
    SELECT 
        Sector,
        Posicion,
        Cod_Producto,
        Nombre_Producto,
        CantidadVendida,
        CONCAT('C$', FORMAT(PrecioVentaPromedio, 2)) AS PrecioPromedio,
        CONCAT('C$', FORMAT(TotalVendido, 2)) AS TotalVendido,
        Icono
    FROM TempTopSector
    ORDER BY Sector, Posicion;
    
    -- Limpieza
    DROP TEMPORARY TABLE IF EXISTS TempTopSector;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-04 21:55:54
